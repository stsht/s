import { buildDeliveryMessage, extractDeliveryPassword } from './src/features/deliveries/deliveryMessages.js';

const ALLOWED_ORIGINS = new Set([
  'https://sshots.pages.dev',
  'https://www.sshots.pages.dev',
  'https://starshots.pages.dev',
  'https://www.starshots.pages.dev',
]);

function resolveAllowedOrigin(request) {
  if (!request) return 'https://sshots.pages.dev';
  const origin = String(request.headers?.get?.('origin') || '').trim();
  if (!origin) return 'https://sshots.pages.dev';
  if (ALLOWED_ORIGINS.has(origin)) return origin;
  try {
    const reqOrigin = new URL(request.url).origin;
    if (origin === reqOrigin) return origin;
  } catch {}
  return 'https://sshots.pages.dev';
}

const corsHeaders = {
  'Access-Control-Allow-Origin': 'https://sshots.pages.dev',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Vary': 'Origin'
};

const SERVICES = [
  { key: 'gd', label: 'Google Drive' },
  { key: 'db', label: 'Dropbox' },
  { key: 'wt', label: 'WeTransfer' }
];

// Generated short codes/passwords intentionally exclude lowercase l.
const SHORT_ALPHABET = '1236789abcdefghijkmnopqrstuvwxyz';
const SHORT_CODE_LENGTH = 12;
const LEGACY_SHORT_CODE_LENGTH = 7;
const GALLERY_PASSWORD_LENGTH = 7;
// Canonical public host for client-facing delivery links.
//
// All copy/share/send paths (WhatsApp template, Instagram DM
// template, /db Short Link card, /l preview) are built off this
// constant so the URL the customer sees is always the deployed
// Pages project host. Admin/internal routes (/db, /inv, /l)
// do not depend on this — they are served from whatever origin the
// operator is currently logged in to.
const PUBLIC_SITE = 'https://sshots.pages.dev';
const LOGO_PATH = '/logo-hero.png';
const ADMIN_SESSION_COOKIE = 'ss_admin_session';
const ADMIN_SESSION_MS = 12 * 60 * 60 * 1000;
const GALLERY_SESSION_COOKIE = 'ss_gallery_session';
const GALLERY_SESSION_MS = 6 * 60 * 60 * 1000;
const GALLERY_HASH_ALGO = 'pbkdf2_sha256';
const GALLERY_HASH_ITERATIONS = 100000;
const RATE_LIMITS = new Map();
let lastRateLimitSweep = 0;
const PUBLIC_PAYMENT_PROOF_MAX_IMAGES = 3;
const PUBLIC_PAYMENT_PROOF_MAX_DATA_CHARS = 790000;
const PAYMENT_PROOF_BUCKET = 'payment-proofs';

function cleanPublicProofImages(images = []) {
  const list = (Array.isArray(images) ? images : [])
    .map((value) => String(value || '').trim())
    .filter(Boolean)
    .slice(0, PUBLIC_PAYMENT_PROOF_MAX_IMAGES);
  if (!list.length) throw new Error('Please upload at least one payment proof.');
  if (list.some((value) => !/^data:image\/(png|jpe?g|webp);base64,/i.test(value))) throw new Error('Payment proof must be an image.');
  if (list.reduce((sum, value) => sum + value.length, 0) > PUBLIC_PAYMENT_PROOF_MAX_DATA_CHARS) {
    throw new Error('Payment proof images are too large.');
  }
  return list;
}

function hasValidImageSignature(bytes, extension) {
  if (!(bytes instanceof Uint8Array) || bytes.length < 12) return false;
  if (extension === 'jpg') {
    return bytes[0] === 0xFF && bytes[1] === 0xD8 && bytes[2] === 0xFF;
  }
  if (extension === 'png') {
    return (
      bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4E && bytes[3] === 0x47
      && bytes[4] === 0x0D && bytes[5] === 0x0A && bytes[6] === 0x1A && bytes[7] === 0x0A
    );
  }
  if (extension === 'webp') {
    return (
      bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46
      && bytes[8] === 0x57 && bytes[9] === 0x45 && bytes[10] === 0x42 && bytes[11] === 0x50
    );
  }
  return false;
}

function parsePaymentProofDataUrl(value) {
  const match = /^data:image\/(png|jpe?g|webp);base64,([a-z0-9+/=\s]+)$/i.exec(String(value || '').trim());
  if (!match) throw new Error('Payment proof must be an image.');
  const subtype = match[1].toLowerCase();
  const extension = subtype === 'jpg' || subtype === 'jpeg' ? 'jpg' : subtype;
  const mimeType = extension === 'jpg' ? 'image/jpeg' : `image/${extension}`;
  const binary = atob(match[2].replace(/\s+/g, ''));
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  if (!hasValidImageSignature(bytes, extension)) {
    throw new Error('Invalid image file content.');
  }
  return { bytes, extension, mimeType };
}

function storageObjectPath(path = '') {
  return String(path || '').split('/').filter(Boolean).map((part) => encodeURIComponent(part)).join('/');
}

async function paymentProofStorageRequest(env, objectPath, options = {}) {
  const { url, key } = getSupabase(env);
  const target = `${url}/storage/v1/object/${storageObjectPath(`${PAYMENT_PROOF_BUCKET}/${objectPath}`)}`;
  const response = await fetch(target, {
    ...options,
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      ...(options.headers || {})
    }
  });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || `Payment proof storage error ${response.status}`);
  }
  return response;
}

function escapeHtml(value = '') {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function responseCorsHeaders(request = null) {
  if (!request) return corsHeaders;
  return {
    ...corsHeaders,
    'Access-Control-Allow-Origin': resolveAllowedOrigin(request),
  };
}

function json(data, status = 200, headers = {}, request = null) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...responseCorsHeaders(request), 'Content-Type': 'application/json; charset=utf-8', ...headers }
  });
}

function getSupabase(env) {
  // Defensive normalisation. PostgREST returns PGRST125 ("Invalid path
  // specified in request URL") whenever the request URL is malformed,
  // and the two malformations we have observed in deploys are:
  //   1. SUPABASE_URL with a trailing slash (or several) -> when our
  //      canonical "/rest/v1/..." paths are appended the resulting
  //      URL contains "//" after the host.
  //   2. SUPABASE_URL configured to already include the "/rest/v1"
  //      suffix -> appending "/rest/v1/..." again produces
  //      "/rest/v1/rest/v1/...", which PostgREST rejects.
  // Stripping both shapes here makes supabaseFetch robust regardless
  // of how SUPABASE_URL is set at deploy time.
  const raw = String(env.SUPABASE_URL || '').trim();
  const url = raw
    .replace(/\/+$/, '')
    .replace(/\/rest\/v1(?:\/.*)?$/i, '');
  const key = env.SUPABASE_SECRET_KEY || '';
  if (!url || !key) throw new Error('Supabase environment variables are missing.');
  return { url, key };
}

async function supabaseFetch(env, path, options = {}) {
  const { url, key } = getSupabase(env);
  const cleanPath = String(path || '').startsWith('/') ? path : `/${path || ''}`;
  // Collapse any accidental "//" inside the path portion (anywhere
  // other than directly after the "https:" scheme separator).
  const target = `${url}${cleanPath}`.replace(/([^:])\/{2,}/g, '$1/');
  const response = await fetch(target, {
    ...options,
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      'Content-Type': 'application/json',
      ...(options.headers || {})
    }
  });

  if (!response.ok) {
    const text = await response.text();
    let parsed = null;
    try { parsed = text ? JSON.parse(text) : null; } catch {}
    const error = new Error(parsed?.message || text || `Supabase error ${response.status}`);
    error.status = response.status;
    error.code = parsed?.code || '';
    error.supabase = true;
    throw error;
  }

  if (response.status === 204) return null;
  const text = await response.text();
  return text ? JSON.parse(text) : null;
}

function getAdminPassword(env) {
  const password = String(env.ADMIN_PASSWORD || '').trim();
  if (!password) {
    throw new Error('ADMIN_PASSWORD Cloudflare Secret is missing. Run: npx wrangler pages secret put ADMIN_PASSWORD --project-name=starshots');
  }
  return password;
}

async function verifyAdminPassword(env, password) {
  return safeEqual(String(password || '').trim(), getAdminPassword(env));
}

function safeEqual(a = '', b = '') {
  const left = String(a);
  const right = String(b);
  let diff = left.length ^ right.length;
  const max = Math.max(left.length, right.length);
  for (let i = 0; i < max; i += 1) diff |= (left.charCodeAt(i) || 0) ^ (right.charCodeAt(i) || 0);
  return diff === 0;
}

function base64UrlEncode(bytes) {
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function randomToken(byteLength = 16) {
  const bytes = new Uint8Array(byteLength);
  crypto.getRandomValues(bytes);
  return base64UrlEncode(bytes);
}

async function sha256Bytes(value) {
  const data = new TextEncoder().encode(String(value || ''));
  return new Uint8Array(await crypto.subtle.digest('SHA-256', data));
}

function codeFromBytes(bytes, length = SHORT_CODE_LENGTH) {
  let code = '';
  for (let i = 0; code.length < length; i += 1) {
    const byte = bytes[i % bytes.length] ^ ((i * 29 + length) & 255);
    code += SHORT_ALPHABET[byte % SHORT_ALPHABET.length];
  }
  return code;
}

function normalizeCodePart(value = '', max = 80) {
  return String(value || '')
    .trim()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/["'’`]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, max);
}

function stripCodeBrackets(value = '') {
  return String(value || '').replace(/\([^)]*\)|\[[^\]]*\]|\{[^}]*\}/g, ' ');
}

function deliveryCodeContext(raw = {}) {
  const folder = normalizeCodePart(raw.folderName || raw.folder_name || raw.baseSlug || raw.base_slug, 160);
  const parts = stripCodeBrackets(folder).split(/\s+/).filter(Boolean);
  let yymmdd = '';
  let firstName = '';
  if (/^\d{6}$/.test(parts[0] || '')) {
    yymmdd = parts[0];
    firstName = parts[1] || '';
  } else if (/^\d{8}$/.test(parts[0] || '')) {
    yymmdd = parts[0].slice(2);
    firstName = parts[1] || '';
  } else {
    firstName = parts[0] || '';
  }
  const clientName = normalizeCodePart(raw.clientName || raw.client_name || raw.name, 160);
  return {
    yymmdd,
    firstName: firstName || clientName.split(' ')[0] || '',
    title: normalizeCodePart((raw.title || raw.client_title) ?? 'Ms.', 20),
    clientName
  };
}

async function contextCode(purpose, length, raw = {}, extra = '') {
  const context = deliveryCodeContext(raw);
  const nonce = randomToken(24);
  const digest = await sha256Bytes([
    purpose,
    context.yymmdd,
    context.firstName,
    context.title,
    context.clientName,
    extra,
    Date.now(),
    nonce
  ].join('|'));
  return codeFromBytes(digest, length);
}

async function hmacSha256(secret, value) {
  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const signature = await crypto.subtle.sign('HMAC', key, encoder.encode(value));
  return base64UrlEncode(new Uint8Array(signature));
}

function getCookie(request, name) {
  const cookies = String(request.headers.get('cookie') || '').split(';');
  const prefix = `${name}=`;
  const match = cookies.map((item) => item.trim()).find((item) => item.startsWith(prefix));
  return match ? decodeURIComponent(match.slice(prefix.length)) : '';
}

async function createAdminSessionCookie(env) {
  const expiresAt = Date.now() + ADMIN_SESSION_MS;
  const nonce = randomToken(12);
  const payload = `${expiresAt}.${nonce}`;
  const signature = await hmacSha256(getAdminPassword(env), payload);
  return `${ADMIN_SESSION_COOKIE}=${encodeURIComponent(`${payload}.${signature}`)}; Path=/; Max-Age=${Math.floor(ADMIN_SESSION_MS / 1000)}; HttpOnly; Secure; SameSite=Lax`;
}

async function createGallerySessionCookie(env, deliveryId) {
  const cleanId = String(deliveryId || '').trim();
  const expiresAt = Date.now() + GALLERY_SESSION_MS;
  const nonce = randomToken(12);
  const payload = `${cleanId}.${expiresAt}.${nonce}`;
  const signature = await hmacSha256(getAdminPassword(env), payload);
  return `${GALLERY_SESSION_COOKIE}=${encodeURIComponent(`${payload}.${signature}`)}; Path=/; Max-Age=${Math.floor(GALLERY_SESSION_MS / 1000)}; HttpOnly; Secure; SameSite=Lax`;
}

async function verifyAdminSessionCookie(request, env) {
  const token = getCookie(request, ADMIN_SESSION_COOKIE);
  const parts = token.split('.');
  if (parts.length !== 3) return false;
  const [expiresAtRaw, nonce, signature] = parts;
  const expiresAt = Number(expiresAtRaw);
  if (!Number.isFinite(expiresAt) || expiresAt < Date.now() || !nonce || !signature) return false;
  const payload = `${expiresAtRaw}.${nonce}`;
  const expected = await hmacSha256(getAdminPassword(env), payload);
  return safeEqual(signature, expected);
}

async function verifyGallerySessionCookie(request, env, deliveryId) {
  const expectedId = String(deliveryId || '').trim();
  const token = getCookie(request, GALLERY_SESSION_COOKIE);
  const parts = token.split('.');
  if (!expectedId || parts.length !== 4) return false;
  const [sessionDeliveryId, expiresAtRaw, nonce, signature] = parts;
  const expiresAt = Number(expiresAtRaw);
  if (sessionDeliveryId !== expectedId || !Number.isFinite(expiresAt) || expiresAt < Date.now() || !nonce || !signature) return false;
  const payload = `${sessionDeliveryId}.${expiresAtRaw}.${nonce}`;
  const expected = await hmacSha256(getAdminPassword(env), payload);
  return safeEqual(signature, expected);
}

async function verifyAdminRequest(request, env, password = '') {
  if (await verifyAdminSessionCookie(request, env)) return true;
  return verifyAdminPassword(env, password);
}

async function deriveGalleryPasswordDigest(password, salt, iterations = GALLERY_HASH_ITERATIONS) {
  const encoder = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey('raw', encoder.encode(String(password || '')), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt: encoder.encode(String(salt || '')), iterations, hash: 'SHA-256' },
    keyMaterial,
    256
  );
  return base64UrlEncode(new Uint8Array(bits));
}

async function hashGalleryPassword(password) {
  const salt = randomToken(16);
  const digest = await deriveGalleryPasswordDigest(password, salt);
  return {
    password_hash: `${GALLERY_HASH_ALGO}$${GALLERY_HASH_ITERATIONS}$${digest}`,
    password_salt: salt
  };
}

function parseGalleryHash(value = '') {
  const raw = String(value || '').trim();
  const parts = raw.split('$');
  if (parts.length === 3 && parts[0] === GALLERY_HASH_ALGO) {
    return { iterations: Number(parts[1]) || GALLERY_HASH_ITERATIONS, digest: parts[2], formatted: true };
  }
  return { iterations: GALLERY_HASH_ITERATIONS, digest: raw, formatted: false };
}

async function verifyGalleryPassword(delivery, password) {
  const hash = String(delivery?.password_hash || '').trim();
  const salt = String(delivery?.password_salt || '').trim();
  if (hash && salt) {
    const parsed = parseGalleryHash(hash);
    if (parsed.iterations > GALLERY_HASH_ITERATIONS) return false;
    const digest = await deriveGalleryPasswordDigest(password, salt, parsed.iterations);
    return safeEqual(digest, parsed.digest);
  }
  return safeEqual(String(delivery?.password || ''), String(password || '').trim());
}

function cleanSlug(value) {
  return String(value || '')
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);
}

function normalizeGalleryCode(value) {
  const normalized = String(value || '')
    .trim()
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  const match = normalized.match(/^(\d{6})\s*([a-z0-9].*)$/);
  if (!match) return '';
  const rest = match[2].trim().replace(/\s+/g, '-').replace(/-+/g, '-').replace(/^-+|-+$/g, '');
  return rest ? `${match[1]}-${rest}`.slice(0, 80) : '';
}


function titleCaseName(value) {
  return String(value || '')
    .trim()
    .replace(/[-_]+/g, ' ')
    .replace(/\s+/g, ' ')
    .split(' ')
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1).toLowerCase())
    .join(' ');
}

function galleryCodeFromSlug(slug) {
  const parts = String(slug || '').split('-').filter(Boolean);
  if (!parts.length) return '';
  return `${parts[0]} ${titleCaseName(parts.slice(1).join(' '))}`.trim();
}





function randomShortCode(length = SHORT_CODE_LENGTH) {
  let code = '';
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  for (const byte of bytes) code += SHORT_ALPHABET[byte % SHORT_ALPHABET.length];
  return code;
}

function cleanShortCode(value) {
  const code = String(value || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  if (code.length === LEGACY_SHORT_CODE_LENGTH) return /^[a-z0-9]{7}$/.test(code) ? code : '';
  if (code.length !== SHORT_CODE_LENGTH) return '';
  return /^[1236789abcdefghijklmnopqrstuvwxyz]+$/.test(code) ? code : '';
}

function shortCodeFromText(value = '') {
  const text = String(value || '');
  // Accept both the current public host (sshots.pages.dev) and the
  // legacy alias (starshots.pages.dev) so old saved messages keep
  // resolving to the same short code on /db. The host change does
  // not affect the slug logic itself.
  const match = text.match(/(?:https?:\/\/)?(?:www\.)?s(?:tar)?shots\.pages\.dev\/([a-z0-9]{7}|[a-z0-9]{12})(?![a-z0-9-])/i);
  return match ? cleanShortCode(match[1]) : '';
}

const PASSWORD_HISTORY_MARKER_RE = /\n?\[SS_PASSWORD_HISTORY:([^\]]*)\]\s*/g;
const ENC_PASSWORD_MARKER_RE = /\n?\[SS_ENC_PASS:v1:([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)\]\s*/;

function base64UrlDecodeBytes(value = '') {
  const base64 = String(value || '').replace(/-/g, '+').replace(/_/g, '/');
  const padded = base64 + '='.repeat((4 - (base64.length % 4)) % 4);
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

async function deriveGalleryCipherKeys(env) {
  const secrets = [
    env?.ENCRYPTION_KEY,
    env?.ADMIN_PASSWORD,
    env?.SUPABASE_SECRET_KEY,
  ].map((s) => String(s || '').trim()).filter(Boolean);
  const uniqueSecrets = [...new Set(secrets)];
  const keys = [];
  for (const secret of uniqueSecrets) {
    const keyBytes = await sha256Bytes(`ss-gallery-aes-gcm-v1|${secret}`);
    const key = await crypto.subtle.importKey('raw', keyBytes, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']);
    keys.push(key);
  }
  return keys;
}

async function encryptGalleryPasswordToken(env, password = '') {
  const clean = String(password || '').trim();
  if (!clean) return '';
  try {
    const keys = await deriveGalleryCipherKeys(env);
    if (!keys.length) return '';
    const iv = new Uint8Array(12);
    crypto.getRandomValues(iv);
    const data = new TextEncoder().encode(clean);
    const cipherBuffer = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, keys[0], data);
    const cipherBytes = new Uint8Array(cipherBuffer);
    return `[SS_ENC_PASS:v1:${base64UrlEncode(iv)}.${base64UrlEncode(cipherBytes)}]`;
  } catch {
    return '';
  }
}

async function decryptGalleryPasswordToken(env, text = '') {
  const match = String(text || '').match(ENC_PASSWORD_MARKER_RE);
  if (!match?.[1] || !match?.[2]) return '';
  try {
    const iv = base64UrlDecodeBytes(match[1]);
    const cipherBytes = base64UrlDecodeBytes(match[2]);
    const keys = await deriveGalleryCipherKeys(env);
    for (const key of keys) {
      try {
        const plainBuffer = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, cipherBytes);
        const decoded = new TextDecoder().decode(plainBuffer).trim();
        if (decoded) return decoded;
      } catch {
        /* try next key */
      }
    }
  } catch {
    /* ignore malformed token */
  }
  return '';
}

function hasStoredDeliveryPassword(delivery = {}) {
  const plain = String(delivery.password || '').trim();
  if (plain && plain !== '[protected]') return true;
  const text = [delivery.generated_text_whatsapp, delivery.generated_text_instagram].filter(Boolean).join('\n');
  if (ENC_PASSWORD_MARKER_RE.test(text)) return true;
  const extracted = extractDeliveryPassword(text);
  return Boolean(extracted && extracted !== '[protected]');
}

async function deliveryPasswordForDisplay(delivery = {}, env = null) {
  const plain = String(delivery.password || '').trim();
  if (plain && plain !== '[protected]') return plain;
  const text = [delivery.generated_text_instagram, delivery.generated_text_whatsapp].filter(Boolean).join('\n');
  if (env && ENC_PASSWORD_MARKER_RE.test(text)) {
    const decrypted = await decryptGalleryPasswordToken(env, text);
    if (decrypted) return decrypted;
  }
  const extracted = extractDeliveryPassword(text);
  return extracted === '[protected]' ? '' : extracted;
}

function stripPasswordHistoryMarker(value = '') {
  return String(value || '')
    .replace(PASSWORD_HISTORY_MARKER_RE, '')
    .replace(ENC_PASSWORD_MARKER_RE, '')
    .trim();
}

function encodePasswordHistoryMarker(history = []) {
  try {
    const payload = encodeURIComponent(JSON.stringify(Array.isArray(history) ? history : []));
    return `[SS_PASSWORD_HISTORY:${payload}]`;
  } catch {
    return '[SS_PASSWORD_HISTORY:%5B%5D]';
  }
}

async function withPasswordHistoryMarker(value = '', history = [], plainPassword = '', env = null) {
  const clean = stripPasswordHistoryMarker(value);
  const markers = [];
  if (Array.isArray(history) && history.length > 0) {
    markers.push(encodePasswordHistoryMarker(history));
  }
  if (plainPassword && env) {
    const encToken = await encryptGalleryPasswordToken(env, plainPassword);
    if (encToken) markers.push(encToken);
  }
  if (!markers.length) return clean;
  return `${clean}\n\n${markers.join('\n')}`;
}

function parsePasswordHistoryValue(value) {
  if (Array.isArray(value)) return value;
  if (typeof value !== 'string' || !value.trim()) return [];
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function passwordHistoryFromGeneratedText(delivery = {}) {
  const text = [delivery.generated_text_instagram, delivery.generated_text_whatsapp].filter(Boolean).join('\n');
  const match = /\[SS_PASSWORD_HISTORY:([^\]]*)\]/.exec(text);
  if (!match?.[1]) return [];
  try {
    const parsed = JSON.parse(decodeURIComponent(match[1]));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function deliveryPasswordHistory(delivery = {}) {
  const direct = parsePasswordHistoryValue(delivery.password_history);
  return direct.length ? direct : passwordHistoryFromGeneratedText(delivery);
}

function deliveryShortCode(delivery = {}) {
  return cleanShortCode(delivery.short_code);
}

async function uniqueShortCode(env, context = {}) {
  for (let i = 0; i < 10; i += 1) {
    const candidate = await contextCode('short-code', SHORT_CODE_LENGTH, context, String(i));
    const existing = await getDeliveryByShortCode(env, candidate).catch(() => null);
    if (!existing) return candidate;
  }
  return randomShortCode();
}

async function generateGalleryPassword(context = {}, shortCode = '') {
  return contextCode('gallery-password', GALLERY_PASSWORD_LENGTH, context, `${shortCode}|${context.title || context.client_title || ''}`);
}

// Build a bag of human-readable date tokens for the /db search index.
//
// The stored value is a bare YYYY-MM-DD, but operators read the
// *visible* date pill ("2 Jun 2026") off a row and search for the
// pieces they see — "Jun", "June", "2026", "26", or one of the
// slash/spaced display forms. This helper emits every one of those
// forms as a single lowercase string so the existing search match
// (`[...].join(' ').toLowerCase().includes(q)`) picks them up with
// no change to the matching logic itself. Returns '' for blank /
// non-date values so it composes cleanly inside a join().
//
// Tokens emitted for 2026-06-02:
//   2026-06-02                       (raw ISO)
//   jun  june                        (month short / full)
//   2026  26                         (year / short year)
//   2  02                            (day / padded day)
//   6  06                            (month number / padded)
//   2 jun 2026   02 jun 2026         (compact pill forms)
//   2 june 2026                      (full-month form)
//   2/6/26   02/06/26   02 / 06 / 26 (slash display forms)
//   2/6/2026  02/06/2026             (slash + full year)
function dateSearchTokens(value) {
  const iso = String(value || '').trim().slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return '';
  const dt = new Date(`${iso}T12:00:00Z`);
  if (Number.isNaN(dt.getTime())) return '';
  const day = dt.getUTCDate();
  const month = dt.getUTCMonth() + 1;
  const year = dt.getUTCFullYear();
  const dd = String(day).padStart(2, '0');
  const mm = String(month).padStart(2, '0');
  const yy = String(year).slice(-2);
  const monShort = dt.toLocaleDateString('en-GB', { month: 'short' });
  const monFull = dt.toLocaleDateString('en-GB', { month: 'long' });
  return [
    iso,
    monShort, monFull,
    String(year), yy,
    String(day), dd,
    String(month), mm,
    `${day} ${monShort} ${year}`,
    `${dd} ${monShort} ${year}`,
    `${day} ${monFull} ${year}`,
    `${day}/${month}/${yy}`,
    `${dd}/${mm}/${yy}`,
    `${dd} / ${mm} / ${yy}`,
    `${day}/${month}/${year}`,
    `${dd}/${mm}/${year}`
  ].join(' ');
}

function deliveryMessageInput({
  title,
  clientName,
  folderName,
  eventDate,
  shortCode,
  password,
  deliveryDone = false
} = {}) {
  return {
    title: title ?? 'Ms.',
    clientName: clientName || '',
    folderName: String(folderName || '').trim() || 'TBA',
    eventDate,
    link: `${PUBLIC_SITE}/${String(shortCode || '').trim()}`,
    password: String(password || '').trim() || '(no password)',
    deliveryDone: deliveryDone === true
  };
}

async function getDeliveryByShortCode(env, code) {
  const target = cleanShortCode(code);
  if (!target) return null;
  try {
    const directRows = await supabaseFetch(
      env,
      `/rest/v1/deliveries?select=*&short_code=eq.${encodeURIComponent(target)}&order=created_at.desc&limit=1`
    );
    const direct = Array.isArray(directRows) ? directRows[0] : directRows;
    if (direct) return direct;
  } catch (error) {
    if (!isSchemaError(error)) throw error;
  }
  // No broader fallback scan: every delivery row has a normalized short_code
  // (checked against the live database), so a miss means the code is unknown.
  return null;
}

async function getDeliveryById(env, id) {
  const deliveryId = String(id || '').trim();
  if (!deliveryId) return null;
  const rows = await supabaseFetch(
    env,
    `/rest/v1/deliveries?select=*&id=eq.${encodeURIComponent(deliveryId)}&limit=1`
  );
  return Array.isArray(rows) ? rows[0] : rows;
}

function cleanService(value) {
  const service = String(value || '').toLowerCase();
  return SERVICES.some((item) => item.key === service) ? service : '';
}

function cleanLogService(value) {
  const service = String(value || '').toLowerCase().replace(/[^a-z0-9_-]+/g, '_').replace(/^_+|_+$/g, '');
  return service.slice(0, 40);
}

function cleanLogEvent(value) {
  const eventType = String(value || 'button_click').toLowerCase().replace(/[^a-z0-9_-]+/g, '_').replace(/^_+|_+$/g, '');
  return (eventType || 'button_click').slice(0, 40);
}

function normalizeUrl(value) {
  let v = String(value || '').trim();
  if (!v) return '';
  if (!/^https?:\/\//i.test(v) && /^(?:[a-z0-9-]+\.)+[a-z]{2,}(?:[/:?#].*)?$/i.test(v)) v = `https://${v}`;
  try {
    const parsed = new URL(v);
    if (!/^https?:$/i.test(parsed.protocol)) return '';
    if (!parsed.hostname || !parsed.hostname.includes('.')) return '';
    return parsed.toString();
  } catch {
    return '';
  }
}

function cleanText(value = '', max = 240) {
  return String(value || '').replace(/\s+/g, ' ').trim().slice(0, max);
}

function titleCaseClientName(value = '') {
  return cleanText(value, 160)
    .toLowerCase()
    .replace(/(^|[^\p{L}\p{N}])(\p{L})/gu, (_, separator, letter) => separator + letter.toUpperCase());
}

function normalizeClientName(value = '') {
  return cleanText(value, 160)
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function normalizeClientContact(value = '') {
  const raw = cleanText(value, 240).toLowerCase();
  // Treat common phone separators as presentation only for phone-like
  // values, so a pasted WhatsApp number and its formatted version match.
  if (/^\+?[\d\s()./-]+$/.test(raw)) {
    const compact = raw.replace(/[\s()./-]/g, '');
    const digits = compact.replace(/^\+/, '');
    if (/^08\d{8,10}$/.test(digits)) return '+62' + digits.slice(1);
    if (/^628\d{8,10}$/.test(digits)) return '+' + digits;
    return compact;
  }
  return raw
    .replace(/\s+/g, '')
    .replace(/[^\d+a-z@._-]/g, '')
    .trim();
}

function cleanClientTitle(value = '') {
  const title = cleanText(value, 20);
  return title ?? 'Ms.';
}

function cleanClientPayload(raw = {}) {
  const name = titleCaseClientName(raw.name ?? raw.client_name ?? raw.clientName);
  return {
    title: cleanClientTitle(raw.title ?? raw.client_title),
    name,
    contact: cleanText(raw.contact ?? raw.client_contact ?? raw.clientContact, 240),
    normalized_name: normalizeClientName(name)
  };
}

function isSchemaError(error) {
  const message = String(error?.message || error || '').toLowerCase();
  return message.includes('schema cache') || message.includes('column') || message.includes('relation') || message.includes('does not exist');
}

function uniqueIds(ids = []) {
  return [...new Set((Array.isArray(ids) ? ids : []).map((id) => String(id || '').trim()).filter(Boolean))];
}

function inFilter(ids = []) {
  return uniqueIds(ids).map((id) => encodeURIComponent(id)).join(',');
}

async function fetchClientById(env, id = '') {
  const cleanId = String(id || '').trim();
  if (!cleanId || cleanId.startsWith('legacy:')) return null;
  try {
    const rows = await supabaseFetch(env, `/rest/v1/clients?select=*&id=eq.${encodeURIComponent(cleanId)}&limit=1`);
    return Array.isArray(rows) ? rows[0] : rows;
  } catch (error) {
    if (isSchemaError(error)) return null;
    throw error;
  }
}

async function fetchClients(env) {
  try {
    const rows = await supabaseFetch(env, '/rest/v1/clients?select=*&order=updated_at.desc&limit=500');
    return Array.isArray(rows) ? rows : [];
  } catch (error) {
    if (isSchemaError(error)) return [];
    throw error;
  }
}

// Whether a contact value is "human-readable enough" to use as a
// duplicate-detection key. Client records store free-text contacts
// (phone, IG handle, IG URL, email), and older imports sometimes left
// junk values (timestamps, opaque
// ids, blanks). When the contact is not recognisably one of those
// shapes we refuse to treat it as a match key — otherwise two
// separate real people with the same name and the same blank
// contact would collapse into a single bucket on save. Mirrors
// the frontend isHumanReadableContact() in WorkspacePages.jsx so
// both surfaces apply the same rule.
function isHumanReadableContactValue(value = '') {
  const v = String(value || '').trim();
  if (!v) return false;
  if (/^\d{4}-\d{2}-\d{2}(T|$)/.test(v)) return false;
  if (/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v)) return true; // email
  if (/^@[a-zA-Z0-9._]+$/.test(v)) return true; // @handle
  if (/instagram\.com\//i.test(v)) return true;
  if (/^(?=.*[a-zA-Z])[a-zA-Z0-9._]{2,30}$/.test(v)) return true; // bare handle
  const digits = v.replace(/[^\d]/g, '');
  if (digits.length >= 6 && /^\+?[\d\s\-().]+$/.test(v)) return true;
  return false;
}

async function findDuplicateClient(env, fields, currentId = '') {
  if (!fields.normalized_name) return null;
  // Refuse to match on non-human-readable contacts so two real
  // clients with the same name but no/blank/garbage contacts are
  // not collapsed. Only an exact match on a recognisable
  // phone/IG/email contact triggers duplicate detection.
  if (!isHumanReadableContactValue(fields.contact)) return null;
  let rows = [];
  try {
    rows = await supabaseFetch(env, `/rest/v1/clients?select=*&normalized_name=eq.${encodeURIComponent(fields.normalized_name)}&limit=50`);
  } catch (error) {
    if (isSchemaError(error)) return null;
    throw error;
  }
  const cleanCurrent = String(currentId || '').trim();
  const contact = normalizeClientContact(fields.contact);
  return (Array.isArray(rows) ? rows : []).find((client) => {
    if (String(client.id || '') === cleanCurrent) return false;
    return normalizeClientContact(client.contact) === contact;
  }) || null;
}

async function findOrCreateClient(env, raw = {}, preferredId = '') {
  const preferred = await fetchClientById(env, preferredId).catch(() => null);
  if (preferred?.id) return preferred;

  const fields = cleanClientPayload(raw);
  if (!fields.normalized_name) return null;

  try {
    const existingRows = await supabaseFetch(env, `/rest/v1/clients?select=*&normalized_name=eq.${encodeURIComponent(fields.normalized_name)}&limit=50`);
    const contact = normalizeClientContact(fields.contact);
    const existingList = Array.isArray(existingRows) ? existingRows : [];
    const existing = existingList.find((client) => normalizeClientContact(client.contact) === contact)
      || (!contact ? existingList.find((client) => !normalizeClientContact(client.contact)) : null);
    if (existing?.id) return existing;

    const rows = await supabaseFetch(env, '/rest/v1/clients', {
      method: 'POST',
      headers: { Prefer: 'return=representation' },
      body: JSON.stringify({
        title: fields.title,
        name: fields.name,
        contact: fields.contact,
        normalized_name: fields.normalized_name,
        updated_at: new Date().toISOString()
      })
    });
    return Array.isArray(rows) ? rows[0] : rows;
  } catch (error) {
    if (isSchemaError(error)) return null;
    throw error;
  }
}

function requestMeta(request) {
  return {
    ip_address: request.headers.get('cf-connecting-ip') || '',
    country: request.cf?.country || request.headers.get('cf-ipcountry') || '',
    city: request.cf?.city || '',
    user_agent: request.headers.get('user-agent') || ''
  };
}

function clientIp(request) {
  return request.headers.get('cf-connecting-ip')
    || String(request.headers.get('x-forwarded-for') || '').split(',')[0].trim()
    || 'local';
}

function sweepRateLimits(now = Date.now()) {
  if (now - lastRateLimitSweep < 5 * 60 * 1000) return;
  lastRateLimitSweep = now;
  for (const [key, item] of RATE_LIMITS.entries()) {
    if ((item.blockedUntil || item.resetAt || 0) < now) RATE_LIMITS.delete(key);
  }
}

function checkRateLimit(request, scope, rule = {}) {
  const now = Date.now();
  sweepRateLimits(now);
  const limit = Number(rule.limit) || 30;
  const windowMs = Number(rule.windowMs) || 60 * 1000;
  const blockMs = Number(rule.blockMs) || 10 * 60 * 1000;
  const key = `${scope}:${clientIp(request)}`;
  const item = RATE_LIMITS.get(key) || { count: 0, resetAt: now + windowMs, blockedUntil: 0 };
  if (item.blockedUntil && item.blockedUntil > now) {
    return { limited: true, retryAfter: Math.ceil((item.blockedUntil - now) / 1000) };
  }
  if (!item.resetAt || item.resetAt <= now) {
    item.count = 0;
    item.resetAt = now + windowMs;
    item.blockedUntil = 0;
  }
  item.count += 1;
  if (item.count > limit) {
    item.blockedUntil = now + blockMs;
    RATE_LIMITS.set(key, item);
    return { limited: true, retryAfter: Math.ceil(blockMs / 1000) };
  }
  RATE_LIMITS.set(key, item);
  return { limited: false, retryAfter: 0 };
}

function rateLimitedResponse(retryAfter = 60, asJson = true) {
  const headers = { 'Retry-After': String(Math.max(1, retryAfter)) };
  return asJson
    ? json({ error: 'Too many attempts. Please try again later.' }, 429, headers)
    : new Response('Too many attempts. Please try again later.', { status: 429, headers: { ...headers, 'Content-Type': 'text/plain; charset=utf-8' } });
}

function enforceRateLimit(request, scope, rule, asJson = true) {
  const result = checkRateLimit(request, scope, rule);
  return result.limited ? rateLimitedResponse(result.retryAfter, asJson) : null;
}

// Clear a rate-limit counter for a specific (scope, IP) pair. Used on
// successful auth so the owner doesn't accumulate failed-attempt
// pressure across legitimate sessions.
function clearRateLimit(request, scope) {
  RATE_LIMITS.delete(`${scope}:${clientIp(request)}`);
}

// Read-only lockout check. Returns whether (scope, IP) is currently
// blocked, WITHOUT incrementing the counter. Used so a successful
// password attempt never contributes toward its own lockout.
function checkLockout(request, scope) {
  const now = Date.now();
  const item = RATE_LIMITS.get(`${scope}:${clientIp(request)}`);
  if (!item || !item.blockedUntil || item.blockedUntil <= now) {
    return { limited: false, retryAfter: 0 };
  }
  return { limited: true, retryAfter: Math.ceil((item.blockedUntil - now) / 1000) };
}

// Record a single failed attempt against (scope, IP). Increments the
// in-window counter and arms the block window once the limit is
// exceeded. Successful attempts MUST NOT call this — see
// handleAdminCheck for the failure-only flow.
function recordFailure(request, scope, rule = {}) {
  const now = Date.now();
  sweepRateLimits(now);
  const limit = Number(rule.limit) || 30;
  const windowMs = Number(rule.windowMs) || 60 * 1000;
  const blockMs = Number(rule.blockMs) || 30 * 1000;
  const key = `${scope}:${clientIp(request)}`;
  const item = RATE_LIMITS.get(key) || { count: 0, resetAt: now + windowMs, blockedUntil: 0 };
  if (!item.resetAt || item.resetAt <= now) {
    item.count = 0;
    item.resetAt = now + windowMs;
    item.blockedUntil = 0;
  }
  item.count += 1;
  if (item.count > limit) {
    item.blockedUntil = now + blockMs;
  }
  RATE_LIMITS.set(key, item);
}




async function insertLog(env, request, deliveryId, eventType, service = null) {
  if (!deliveryId || !eventType) return;
  const meta = requestMeta(request);
  await supabaseFetch(env, '/rest/v1/delivery_access_logs', {
    method: 'POST',
    headers: { Prefer: 'return=minimal' },
    body: JSON.stringify({
      delivery_id: deliveryId,
      event_type: eventType,
      service,
      ...meta
    })
  }).catch(() => {});
}


async function getLatestDeliveryBySlug(env, slug) {
  const clean = cleanSlug(slug);
  if (!clean) return null;
  const rows = await supabaseFetch(
    env,
    `/rest/v1/deliveries?select=*&base_slug=eq.${encodeURIComponent(clean)}&order=created_at.desc&limit=1`
  );
  return Array.isArray(rows) ? rows[0] : null;
}

async function getDeliveryByLookup(env, value) {
  const shortCode = cleanShortCode(value);
  if (shortCode) return getDeliveryByShortCode(env, shortCode);
  return getLatestDeliveryBySlug(env, value);
}

function explicitShortCode(delivery = {}) {
  return cleanShortCode(delivery.short_code)
    || shortCodeFromText(delivery.generated_text_whatsapp)
    || shortCodeFromText(delivery.generated_text_instagram);
}

function shouldBlockFolderSlug(delivery = {}) {
  if (!delivery) return false;
  const hasPassword = String(delivery.password_hash || delivery.password || '').trim()
    || hasStoredDeliveryPassword(delivery);
  return !!(explicitShortCode(delivery) && hasPassword);
}

async function getLinksByDeliveryId(env, deliveryId) {
  if (!deliveryId) return [];
  const rows = await supabaseFetch(
    env,
    `/rest/v1/delivery_links?select=*&delivery_id=eq.${encodeURIComponent(deliveryId)}&order=created_at.asc`
  );
  return Array.isArray(rows) ? rows : [];
}

async function publicDeliveryPayload(env, delivery) {
  const rows = await getLinksByDeliveryId(env, delivery.id);
  const links = SERVICES.map((service) => {
    const row = rows.find((item) => item.service === service.key);
    const openUrl = row?.original_url
      ? `/api/open-link?deliveryId=${encodeURIComponent(delivery.id)}&service=${encodeURIComponent(service.key)}`
      : '';
    return {
      service: service.key,
      label: service.label,
      url: openUrl,
      originalUrl: row?.original_url || '',
      openUrl,
      link_done: row ? !!row.link_done : false
    };
  });

  const invoice = await findInvoiceForDelivery(env, delivery).catch(() => null);

  return {
    delivery: {
      id: delivery.id,
      title: delivery.title,
      clientName: delivery.client_name,
      folderName: delivery.folder_name,
      baseSlug: delivery.base_slug,
      eventDate: delivery.event_date || '',
      delivery_done: !!delivery.delivery_done,
      deliveryDone: !!delivery.delivery_done
    },
    links,
    invoice: invoiceSummary(invoice)
  };
}

function invoiceDeliveryScore(invoice = {}, delivery = {}) {
  const data = invoice.invoice_data && typeof invoice.invoice_data === 'object' ? invoice.invoice_data : {};
  const deliveryId = String(delivery.id || '');
  const deliveryEventKey = String(delivery.event_key || '');
  const invoiceEventKey = String(invoice.event_key || data.event_key || '');
  const deliveryClientId = String(delivery.client_id || '');
  const invoiceClientId = String(invoice.client_id || '');
  const deliveryName = normalizeClientName(delivery.client_name || '');
  const invoiceName = normalizeClientName(invoice.client_name || '');
  const deliveryDate = String(delivery.event_date || '');
  const invoiceDate = String(invoice.event_date || '');

  if (deliveryId && String(data.delivery_id || '') === deliveryId) return 100;
  if (deliveryEventKey && invoiceEventKey && deliveryEventKey === invoiceEventKey) return 90;
  // If both carry an explicit event_key (or delivery_id) and they differ,
  // they are separate events on the same day (e.g. Morning vs Evening)
  // and must never cross-match by date alone.
  if (deliveryId && data.delivery_id && String(data.delivery_id) !== deliveryId) return 0;
  if (deliveryEventKey && invoiceEventKey && deliveryEventKey !== invoiceEventKey) return 0;
  if (!deliveryEventKey && !invoiceEventKey) {
    if (deliveryClientId && invoiceClientId && deliveryClientId === invoiceClientId && deliveryDate && invoiceDate && deliveryDate === invoiceDate) return 80;
    if (deliveryName && invoiceName && deliveryName === invoiceName && deliveryDate && invoiceDate && deliveryDate === invoiceDate) return 70;
  }
  return 0;
}

function invoiceRecordType(invoice = {}) {
  if (!invoice || typeof invoice !== 'object') return 'client';
  const data = invoice.invoice_data && typeof invoice.invoice_data === 'object' ? invoice.invoice_data : {};
  const type = String(invoice.invoice_type || data.invoiceType || '').trim().toLowerCase();
  return type === 'vendor' ? 'vendor' : 'client';
}


function deliveryInvoiceAudience(delivery = {}, exactRows = []) {
  const explicit = String(delivery.type || '').trim().toLowerCase();
  if (explicit === 'vendor' || explicit === 'client') return explicit;
  const hasVendorExact = (Array.isArray(exactRows) ? exactRows : []).some((row) => invoiceRecordType(row) === 'vendor');
  const hasClientExact = (Array.isArray(exactRows) ? exactRows : []).some((row) => invoiceRecordType(row) !== 'vendor');
  if (hasVendorExact && !hasClientExact) return 'vendor';
  if (hasClientExact && !hasVendorExact) return 'client';
  return 'client';
}

async function findInvoiceForDelivery(env, delivery = {}) {
  const deliveryId = String(delivery.id || '').trim();
  if (!deliveryId) return null;

  let exactRows = [];
  try {
    exactRows = await supabaseFetch(
      env,
      `/rest/v1/invoices?select=*&invoice_data->>delivery_id=eq.${encodeURIComponent(deliveryId)}&order=updated_at.desc&limit=10`
    );
    exactRows = Array.isArray(exactRows) ? exactRows : [exactRows].filter(Boolean);
    const audience = deliveryInvoiceAudience(delivery, exactRows);
    const exact = exactRows.find((row) => invoiceRecordType(row) === audience);
    if (exact) return exact;
  } catch (error) {
    if (!isSchemaError(error)) console.warn('[public-invoice] jsonb delivery lookup failed:', error?.message || error);
  }

  const audience = deliveryInvoiceAudience(delivery, exactRows);
  const deliveryEventKey = String(delivery.event_key || '').trim();
  if (deliveryEventKey) {
    const eventKeyRows = [];
    const addEventKeyRows = (rows) => {
      (Array.isArray(rows) ? rows : [rows].filter(Boolean)).forEach((row) => eventKeyRows.push(row));
    };
    addEventKeyRows(await supabaseFetch(
      env,
      `/rest/v1/invoices?select=*&event_key=eq.${encodeURIComponent(deliveryEventKey)}&order=updated_at.desc&limit=10`
    ).catch(() => []));
    addEventKeyRows(await supabaseFetch(
      env,
      `/rest/v1/invoices?select=*&invoice_data->>event_key=eq.${encodeURIComponent(deliveryEventKey)}&order=updated_at.desc&limit=10`
    ).catch(() => []));
    const exactEvent = eventKeyRows.find((row) => invoiceRecordType(row) === audience);
    if (exactEvent) return exactEvent;
  }

  const candidates = [];
  const seen = new Set();
  const addRows = (rows) => {
    (Array.isArray(rows) ? rows : []).forEach((row) => {
      const id = String(row?.id || '');
      if (!id || seen.has(id)) return;
      if (invoiceRecordType(row) !== audience) return;
      seen.add(id);
      candidates.push(row);
    });
  };

  const clientId = String(delivery.client_id || '').trim();
  if (clientId) {
    addRows(await supabaseFetch(
      env,
      `/rest/v1/invoices?select=*&client_id=eq.${encodeURIComponent(clientId)}&order=updated_at.desc&limit=50`
    ).catch(() => []));
  }

  const clientName = String(delivery.client_name || '').trim();
  if (clientName) {
    addRows(await supabaseFetch(
      env,
      `/rest/v1/invoices?select=*&client_name=eq.${encodeURIComponent(clientName)}&order=updated_at.desc&limit=50`
    ).catch(() => []));
  }

  if (!candidates.length) return null;

  // Confident match: explicit delivery link (100), event key (90), or a
  // client_id/name match that ALSO agrees on event_date (80/70). These
  // are safe to expose publicly without further checks.
  const confident = candidates
    .map((invoice) => ({ invoice, score: invoiceDeliveryScore(invoice, delivery) }))
    .filter((item) => item.score >= 70)
    .sort((a, b) => b.score - a.score)[0]?.invoice;
  if (confident) return confident;

  // Do not fall back to "newest invoice for this client" or to a
  // client-only match. When clients have multiple event dates, public
  // delivery pages must either match the delivery_id/event_key or agree
  // on client_id/name plus event_date.
  return null;
}

function buildClientSummaries(clientRows = [], invoices = [], deliveries = [], q = '') {
  const byId = new Map();
  const byNormalized = new Map();
  const legacy = new Map();

  const makeSummary = (source, seed = {}) => ({
    id: source === 'client' ? String(seed.id || '') : `legacy:${seed.normalized_name || 'unknown'}`,
    client_id: source === 'client' ? String(seed.id || '') : '',
    source,
    title: cleanClientTitle(seed.title || seed.client_title),
    name: cleanText(seed.name || seed.client_name || 'Client', 160),
    contact: cleanText(seed.contact || seed.client_contact || '', 240),
    normalized_name: seed.normalized_name || normalizeClientName(seed.name || seed.client_name),
    updated_at: seed.updated_at || seed.created_at || '',
    invoice_count: 0,
    delivery_count: 0,
    invoice_ids: [],
    delivery_ids: [],
  });

  (Array.isArray(clientRows) ? clientRows : []).forEach((client) => {
    const summary = makeSummary('client', client);
    if (!summary.client_id || !summary.normalized_name) return;
    byId.set(summary.client_id, summary);
    if (!byNormalized.has(summary.normalized_name)) byNormalized.set(summary.normalized_name, summary);
  });

  // Bucketing for invoice/delivery rows. Either lands in an
  // existing real client bucket (by client_id or normalized_name)
  // or creates a `legacy:<name>` bucket so old rows that pre-date
  // the typed client_id column still group under their name. This
  // is the path that fuels the Clients tab on /db.
  const bucketFor = (record) => {
    const clientId = String(record.client_id || '').trim();
    if (clientId && byId.has(clientId)) return byId.get(clientId);
    const normalized = normalizeClientName(record.client_name || record.name);
    if (!normalized) return null;
    if (byNormalized.has(normalized)) return byNormalized.get(normalized);
    if (!legacy.has(normalized)) legacy.set(normalized, makeSummary('legacy', { ...record, normalized_name: normalized }));
    const summary = legacy.get(normalized);
    if (!summary.contact && record.client_contact) summary.contact = cleanText(record.client_contact, 240);
    if (!summary.updated_at || new Date(record.updated_at || record.created_at || 0) > new Date(summary.updated_at || 0)) {
      summary.updated_at = record.updated_at || record.created_at || summary.updated_at;
    }
    return summary;
  };

  // Event dates per client, kept in a side map keyed by the summary
  // object so they feed the search index WITHOUT bloating the
  // `clients` payload returned to the frontend (which computes its
  // own pill dates from invoices/deliveries). These are exactly the
  // event_dates that drive the visible date pill on a client row, so
  // searching the pill text ("Jun", "2026", "02/06/26", …) matches.
  const eventDatesBySummary = new Map();
  const noteEventDate = (summary, value) => {
    const iso = String(value || '').trim().slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return;
    let set = eventDatesBySummary.get(summary);
    if (!set) { set = new Set(); eventDatesBySummary.set(summary, set); }
    set.add(iso);
  };

  (Array.isArray(invoices) ? invoices : []).forEach((invoice) => {
    const summary = bucketFor(invoice);
    if (!summary) return;
    summary.invoice_count += 1;
    summary.invoice_ids.push(String(invoice.id));
    if (!summary.contact && invoice.client_contact) summary.contact = cleanText(invoice.client_contact, 240);
    noteEventDate(summary, invoice.event_date);
  });

  (Array.isArray(deliveries) ? deliveries : []).forEach((delivery) => {
    const summary = bucketFor(delivery);
    if (!summary) return;
    summary.delivery_count += 1;
    summary.delivery_ids.push(String(delivery.id));
    noteEventDate(summary, delivery.event_date);
  });

  const query = String(q || '').toLowerCase();
  return [...byId.values(), ...legacy.values()]
    .filter((client) => {
      const invoiceCount = Number(client.invoice_count || 0);
      const deliveryCount = Number(client.delivery_count || 0);
      const hasCrmHistory = invoiceCount > 0 || deliveryCount > 0;

      // Legacy buckets are denormalized stubs — only keep them
      // when they actually carry CRM history. (Construction also
      // enforces this since legacy buckets are only created from
      // invoice/delivery rows above.)
      if (client.source === 'legacy') return hasCrmHistory;

      return true;
    })
    .filter((client) => !query || [
      client.title,
      client.name,
      client.contact,
      client.normalized_name,
      client.invoice_count,
      client.delivery_count,
      [...(eventDatesBySummary.get(client) || [])].map(dateSearchTokens).join(' ')
    ].join(' ').toLowerCase().includes(query))
    .sort((a, b) => (Date.parse(b.updated_at || '') || 0) - (Date.parse(a.updated_at || '') || 0))
    .slice(0, 300);
}

function clientMatchKeys(record = {}) {
  const keys = [];
  const clientId = String(record.client_id || '').trim();
  const normalized = normalizeClientName(record.client_name || record.name);
  if (clientId) keys.push(`id:${clientId}`);
  if (normalized) keys.push(`name:${normalized}`);
  return keys;
}

function latestByClientKey(records = []) {
  const map = new Map();
  (Array.isArray(records) ? records : []).forEach((record) => {
    clientMatchKeys(record).forEach((key) => {
      if (!map.has(key)) map.set(key, record);
    });
  });
  return map;
}

function relatedByClientKey(record = {}, map = new Map()) {
  for (const key of clientMatchKeys(record)) {
    if (map.has(key)) return map.get(key);
  }
  return null;
}

function invoiceSummary(invoice = null) {
  if (!invoice?.id) return null;
  return {
    id: invoice.id,
    client_name: invoice.client_name || '',
    client_title: invoice.client_title || '',
    invoice_date: invoice.invoice_date || '',
    event_date: invoice.event_date || '',
    status: invoice.status || '',
    updated_at: invoice.updated_at || ''
  };
}

function deliverySummary(delivery = null) {
  if (!delivery?.id) return null;
  const shortCode = deliveryShortCode(delivery);
  const shortPath = shortCode ? `/${shortCode}` : '';
  return {
    id: delivery.id,
    client_name: delivery.client_name || '',
    folder_name: delivery.folder_name || '',
    delivery_year: delivery.delivery_year || '',
    delivery_month: delivery.delivery_month || '',
    base_slug: delivery.base_slug || '',
    short_code: shortCode,
    delivery_url: shortPath,
    short_url: shortPath
  };
}

async function patchRowsByIds(env, table, ids = [], payload = {}, clientId = '') {
  const cleanIds = uniqueIds(ids);
  if (!cleanIds.length) return [];
  const path = `/rest/v1/${table}?id=in.(${inFilter(cleanIds)})`;
  const withClient = clientId ? { ...payload, client_id: clientId } : payload;
  try {
    const rows = await supabaseFetch(env, path, {
      method: 'PATCH',
      headers: { Prefer: 'return=representation' },
      body: JSON.stringify(withClient)
    });
    return Array.isArray(rows) ? rows : [];
  } catch (error) {
    if (!clientId || !isSchemaError(error)) throw error;
    const rows = await supabaseFetch(env, path, {
      method: 'PATCH',
      headers: { Prefer: 'return=representation' },
      body: JSON.stringify(payload)
    });
    return Array.isArray(rows) ? rows : [];
  }
}

async function patchRowsByClientId(env, table, clientId = '', payload = {}) {
  if (!clientId) return [];
  try {
    const rows = await supabaseFetch(env, `/rest/v1/${table}?client_id=eq.${encodeURIComponent(clientId)}`, {
      method: 'PATCH',
      headers: { Prefer: 'return=representation' },
      body: JSON.stringify(payload)
    });
    return Array.isArray(rows) ? rows : [];
  } catch (error) {
    if (isSchemaError(error)) return [];
    throw error;
  }
}

function shellStyles() {
  return `
    @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500;600;700&display=swap');
    :root{
      color-scheme:light;
      --bg:#F6F6F3;--bg2:#F6F6F3;--card:#FFFFFF;--solid:#ffffff;--field:#f8f8f6;
      --ink:#1f1a17;--soft:#69645f;--muted:#98928b;--line:#e4e2dc;--line2:#d6d3cc;
      --accent:#5f95f5;--accent2:#4f86ee;--accentSoft:rgba(95,149,245,.12);--disabled:#e5ded3;
      --green:#357f58;--danger:#bc3b42;--shadow:0 30px 90px rgba(30,30,28,.10);--shadow2:0 12px 34px rgba(30,30,28,.07);
      --glow1:rgba(255,255,255,.66);--glow2:rgba(212,205,188,.08);--grain:rgba(80,64,44,.028);
    }
    @media(prefers-color-scheme:dark){
      :root{
        color-scheme:dark;--bg:#11110F;--bg2:#11110F;--card:#171613;--solid:#1c1b17;--field:#141310;
        --ink:#f4eee5;--soft:#b8aea2;--muted:#8f8579;--line:#2b2823;--line2:#3a352e;
        --accent:#8ab4f8;--accent2:#5f95f5;--accentSoft:rgba(138,180,248,.16);--disabled:#2f2b26;
        --green:#77d5a4;--danger:#ff737a;--shadow:0 30px 90px rgba(0,0,0,.36);--shadow2:0 14px 40px rgba(0,0,0,.24);
        --glow1:rgba(138,180,248,.05);--glow2:rgba(66,133,244,.08);--grain:rgba(245,249,255,.026);
      }
    }
    *{box-sizing:border-box}
    html,body{margin:0;padding:0;min-height:100%}
    body{
      min-height:100dvh;font-family:"Cormorant Garamond","Times New Roman",Georgia,serif;font-weight:500;color:var(--ink);
      background:var(--bg);
      padding:18px;overflow-x:hidden;
    }
    body:before{display:none}
    a{color:inherit}
    .wrap{position:relative;z-index:1;max-width:1160px;margin:0 auto}
    .center{display:grid;place-items:center;min-height:calc(100dvh - 36px)}
    .top{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:18px}
    .logo-link{display:inline-flex;align-items:center;justify-content:center;text-decoration:none;background:transparent;border:0;border-radius:0;padding:0;box-shadow:none;transition:transform .15s ease,opacity .15s ease}
    .logo-link:hover{transform:translateY(-1px);opacity:.9}
    .logo{display:block;width:min(240px,66vw);height:auto;object-fit:contain}
    .logo.hero{width:min(480px,84vw)}
    .logo.compact{width:min(190px,48vw)}
    .top .logo{width:min(190px,48vw)}
    @media(prefers-color-scheme:dark){.logo,.home-logo{filter:brightness(0) invert(1) sepia(.08) saturate(.7);opacity:.92}}
    .pill{border:1px solid var(--line);background:var(--card);border-radius:999px;padding:10px 14px;color:var(--soft);font-size:13px;font-weight:750}
    .panel,.card{background:var(--card);border:1px solid var(--line);box-shadow:var(--shadow);border-radius:36px;padding:26px;backdrop-filter:blur(22px);-webkit-backdrop-filter:blur(22px);-webkit-backface-visibility:hidden;backface-visibility:hidden;-webkit-transform:translateZ(0);transform:translateZ(0)}
    .card{width:min(100%,560px);margin-inline:auto}
    .lift{transform:translateY(-18px)}
    h1,h2,h3{margin:0;letter-spacing:-.04em}
    h1{font-size:clamp(30px,5vw,48px);line-height:1.02;margin-bottom:10px}
    h2{font-size:25px}
    h3{font-size:16px}
    p{margin:0;color:var(--soft);line-height:1.55}
    .sub{margin-bottom:20px}
    .tiny{font-size:12px;color:var(--muted);margin-top:20px;text-align:center}
    .hero-card{text-align:center;width:min(100%,820px);padding:40px 34px}
    .hero-copy{font-size:17px;max-width:580px;margin:0 auto;color:var(--soft)}
    .cta-row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap;margin-top:26px}
    .micro{font-size:12px;color:var(--muted);margin-top:20px}
    .field{margin-top:18px}
    label{display:block;font-size:13px;font-weight:760;margin:0 0 8px;color:var(--ink)}
    input,textarea{width:100%;border:1px solid var(--line);background:var(--field);color:var(--ink);border-radius:20px;padding:15px 16px;font-size:16px;outline:none}
    input:focus,textarea:focus{border-color:var(--accent);box-shadow:0 0 0 5px var(--accentSoft)}
    .password-wrap{position:relative}
    .password-wrap input{padding-right:56px}
    .eye-btn{position:absolute;right:14px;top:50%;transform:translateY(-50%);width:24px;height:24px;min-height:24px;padding:0;border:0;border-radius:0;background:transparent;display:grid;place-items:center;cursor:pointer;color:var(--soft);box-shadow:none;-webkit-appearance:none;appearance:none}
    .eye-btn svg{width:24px;height:24px;stroke:currentColor;fill:none;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round}
    .eye-btn:hover{color:var(--ink);background:transparent}
    button:not(.eye-btn),.btn{border:0;border-radius:999px;min-height:54px;padding:15px 20px;font:800 16px/1 inherit;cursor:pointer;text-decoration:none;display:flex;align-items:center;justify-content:center;text-align:center;gap:8px;transition:transform .15s ease,opacity .15s ease,background .15s ease,box-shadow .15s ease}
    .primary{color:#fff;background:var(--accent);box-shadow:0 14px 28px rgba(30,30,28,.12)}
    .ghost{background:var(--solid);color:var(--ink);border:1px solid var(--line)}
    .danger{background:#a93f40;color:#fff;box-shadow:0 14px 28px rgba(169,63,64,.16)}
    button:not(.eye-btn):hover,.btn:hover{transform:translateY(-1px)}
    button:not(.eye-btn):active,.btn:active{transform:translateY(0) scale(.99)}
    .links{display:none;margin-top:18px;gap:12px;flex-direction:column}
    .links.ready{display:flex}
    .service{border:1px solid var(--line);background:var(--solid);color:var(--ink);justify-content:center;text-align:center;width:100%}
    .service.active{background:var(--accent);color:#fff}
    .service.disabled{cursor:not-allowed;background:var(--disabled);color:var(--muted);opacity:.78}
    .status{min-height:20px;margin-top:14px;font-size:13px;font-weight:750;color:var(--soft)}
    .status.ok{color:var(--green)}
    .status.err{color:var(--danger)}
    .hidden{display:none!important}
    .grid{display:grid;grid-template-columns:340px 1fr;gap:14px}
    .search{width:100%;margin-bottom:12px}
    .list{display:flex;flex-direction:column;gap:10px;max-height:calc(100dvh - 168px);overflow:auto;scrollbar-width:none}
    .list::-webkit-scrollbar{display:none}
    .item-row{display:grid;grid-template-columns:1fr 42px;gap:8px;align-items:stretch}
    .item{border:1px solid var(--line);background:var(--solid);border-radius:20px;padding:14px;text-align:left;cursor:pointer;color:var(--ink);width:100%;min-height:auto;display:block}
    .item.active{border-color:var(--accent);box-shadow:0 0 0 4px rgba(95,149,245,.12)}
    .item b{display:block;font-size:15px}
    .item span{font-size:12px;color:var(--soft)}
    .more{border:1px solid var(--line)!important;background:var(--solid)!important;color:var(--soft)!important;border-radius:18px!important;min-height:auto!important;padding:0!important;font-size:22px!important;line-height:1!important;box-shadow:none!important}
    .more:hover{color:var(--danger)!important;background:rgba(188,59,66,.08)!important}
    .copyable{cursor:pointer;transition:border-color .15s ease,box-shadow .15s ease,transform .15s ease}
    .copyable:hover{border-color:var(--accent);box-shadow:0 0 0 4px var(--accentSoft);transform:translateY(-1px)}
    .copy-note{font-size:11px;color:var(--muted);font-weight:750;margin-left:8px}
    .detail{min-height:calc(100dvh - 126px)}
    .chips{display:flex;gap:8px;flex-wrap:wrap;margin:16px 0}
    .chip{border:1px solid var(--line);background:var(--solid);border-radius:999px;padding:8px 11px;font-size:12px;color:var(--soft)}
    .chip.ok{color:var(--green)}
    .box{border:1px solid var(--line);background:var(--solid);border-radius:22px;padding:14px;margin-top:12px}
    .row{display:flex;gap:10px;justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--line)}
    .row:last-child{border-bottom:0}
    .row small{color:var(--soft)}
    pre{white-space:pre-wrap;word-break:break-word;margin:0;color:var(--soft);font-family:"Cormorant Garamond","Times New Roman",Georgia,serif;font-weight:500;font-size:13px;line-height:1.45}
    .toolbar{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}
    @media(max-width:800px){.grid{grid-template-columns:1fr}.detail{min-height:auto}.list{max-height:40dvh}.top{align-items:flex-start}.top .logo,.logo.compact{width:min(180px,54vw)}}
    @media(max-width:480px){body{padding:14px}.card,.panel{border-radius:30px;padding:22px}.hero-card{padding:30px 22px}.logo.hero{width:min(430px,88vw)}.cta-row .btn{width:100%}.lift{transform:translateY(-10px)}}
  `;
}

function animateAssets() {
  return `<link rel="stylesheet" href="/animate.css">
    <link rel="stylesheet" href="/gate.css">
    <script src="/animate.js"></script>
    <script src="/gate.js"></script>`;
}


async function handleAdminCheck(request, env) {
  const body = await request.json().catch(() => ({}));
  const password = String(body.password || '').trim();

  // Empty-password POSTs are session-revalidation pings from the
  // PasswordGate useEffect (and the cross-tab cookie probe). They
  // can only succeed with a valid signed cookie, so they are not a
  // brute-force surface. They MUST NOT count toward the lockout —
  // routine page loads and tab refreshes would otherwise drain the
  // budget and lock the owner out.
  if (!password) {
    if (await verifyAdminSessionCookie(request, env)) {
      return json({ ok: true }, 200, { 'Set-Cookie': await createAdminSessionCookie(env) });
    }
    return json({ error: 'Unauthorized.' }, 401);
  }

  // If this IP is currently locked out, refuse the attempt without
  // verifying the password and without incrementing any counter.
  // Block window is capped at 30s (see recordFailure default).
  const lockout = checkLockout(request, 'admin-check');
  if (lockout.limited) return rateLimitedResponse(lockout.retryAfter);

  if (!(await verifyAdminPassword(env, password))) {
    // ONLY failed attempts count toward the lockout. A correct
    // password no longer increments the counter, so legitimate
    // re-authentication never trips the limiter.
    recordFailure(request, 'admin-check', { limit: 8, windowMs: 60 * 1000, blockMs: 30 * 1000 });
    return json({ error: 'Unauthorized.' }, 401);
  }

  // Correct password: drop the failure counter for this IP entirely.
  // Subsequent attempts in the same window start fresh.
  clearRateLimit(request, 'admin-check');
  return json({ ok: true }, 200, { 'Set-Cookie': await createAdminSessionCookie(env) });
}

async function handleSave(request, env) {
  const body = await request.json();
  const adminPassword = String(body.adminPassword || '').trim();
  if (!(await verifyAdminRequest(request, env, adminPassword))) return json({ error: 'Unauthorized.' }, 401);
  const links = Array.isArray(body.links) ? body.links : [];
  const cleanLinks = links
    .map((link) => {
      let isDone = false;
      if (typeof link.link_done === 'boolean') isDone = link.link_done;
      else if (typeof link.linkDone === 'boolean') isDone = link.linkDone;
      else if (typeof link.done === 'boolean') isDone = link.done;
      else if (link.link_done === 'true' || link.linkDone === 'true' || link.done === 'true') isDone = true;
      return {
        service: cleanService(link.service),
        originalUrl: normalizeUrl(link.originalUrl || link.original_url || link.url),
        link_done: isDone
      };
    })
    .filter((link) => link.service && link.originalUrl);

  const baseSlug = cleanSlug(body.baseSlug);
  if (!body.clientName || !body.folderName || !baseSlug) {
    return json({ error: 'Missing required delivery data.' }, 400);
  }

  const deliveryYear = Number(body.deliveryYear) || new Date().getFullYear();
  const deliveryMonth = Number(body.deliveryMonth) || new Date().getMonth() + 1;
  const deliveryContext = { ...body, baseSlug };
  const shortCode = await uniqueShortCode(env, deliveryContext);
  const password = await generateGalleryPassword(deliveryContext, shortCode);
  const deliveryUrl = `/${shortCode}`;
  const messageInput = deliveryMessageInput({
    title: body.title ?? 'Ms.',
    clientName: body.clientName,
    folderName: body.folderName,
    eventDate: body.eventDate,
    shortCode,
    password
  });
  const generatedText = buildDeliveryMessage(messageInput);
  const redactedMessage = buildDeliveryMessage({ ...messageInput, password: '[protected]' });
  const storedGeneratedTextWa = redactedMessage;
  const storedGeneratedTextIg = await withPasswordHistoryMarker(redactedMessage, [], password, env);
  const passwordSecurity = await hashGalleryPassword(password);
  const invoiceId = String(body.invoiceId || '').trim();
  let linkedInvoice = null;
  if (invoiceId) {
    linkedInvoice = await supabaseFetch(env, `/rest/v1/invoices?select=*&id=eq.${encodeURIComponent(invoiceId)}&limit=1`)
      .then((rows) => Array.isArray(rows) ? rows[0] : rows)
      .catch(() => null);
  }
  // Stable parent clients.id forwarded from /db's Create Events
  // sheet (or /inv when an invoice originated there). When set, it
  // takes priority over the linked invoice's client_id and acts as
  // the preferredId for findOrCreateClient — guaranteeing that a
  // new delivery saved from a selected /db client attaches to THAT
  // exact clients row instead of name+contact-matching its way to
  // a duplicate sibling. fetchClientById inside findOrCreateClient
  // already validates the id, so a stale/unknown value falls
  // through to the legacy name+contact lookup safely.
  const handoffClientId = String(body.clientId || '').trim().slice(0, 80);
  const preferredClientId = handoffClientId || String(linkedInvoice?.client_id || '').trim();
  const client = await findOrCreateClient(env, {
    title: (linkedInvoice?.client_title || body.title) ?? 'Ms.',
    name: linkedInvoice?.client_name || body.clientName,
    contact: linkedInvoice?.client_contact || ''
  }, preferredClientId);
  const clientId = client?.id ? String(client.id) : '';
  if (linkedInvoice?.id && clientId && !linkedInvoice.client_id) {
    await patchRowsByIds(env, 'invoices', [linkedInvoice.id], {}, clientId).catch(() => []);
  }

  const baseRecord = {
    title: String(body.title ?? 'Ms.').slice(0, 12),
    client_name: String(body.clientName).trim(),
    folder_name: String(body.folderName).trim(),
    base_slug: baseSlug,
    password,
    delivery_year: deliveryYear,
    delivery_month: deliveryMonth,
    generated_text_whatsapp: storedGeneratedTextWa,
    generated_text_instagram: storedGeneratedTextIg
  };
  // Optional event grouping fields. event_date stays a bare
  // YYYY-MM-DD (or empty for TBA); event_key is whatever the
  // frontend handed us (an existing row's event_key, the
  // anchor row's id used as a cross-ref, or a fresh UUID for
  // brand-new top-level events). Both are dropped at the
  // schema-fallback layer below if the columns don't exist on
  // a legacy schema.
  const eventDateRaw = String(body.eventDate || '').trim();
  const eventDate = /^\d{4}-\d{2}-\d{2}$/.test(eventDateRaw) ? eventDateRaw : '';
  const eventKey = String(body.eventKey || '').trim().slice(0, 80);
  const eventFields = {};
  if (eventDate) eventFields.event_date = eventDate;
  if (eventKey) eventFields.event_key = eventKey;
  Object.assign(baseRecord, eventFields);
  const linkedRecord = clientId ? { ...baseRecord, client_id: clientId } : baseRecord;
  const stripEvent = (record) => {
    const next = { ...record };
    delete next.event_date;
    delete next.event_key;
    return next;
  };
  const recordVariants = [
    { record: { ...linkedRecord, password: '', ...passwordSecurity, short_code: shortCode }, stripped: false },
    { record: { ...stripEvent(linkedRecord), password: '', ...passwordSecurity, short_code: shortCode }, stripped: true },
    { record: { ...baseRecord, password: '', ...passwordSecurity, short_code: shortCode }, stripped: false },
    { record: { ...stripEvent(baseRecord), password: '', ...passwordSecurity, short_code: shortCode }, stripped: true },
    { record: { ...linkedRecord, password: '', ...passwordSecurity }, stripped: false },
    { record: { ...stripEvent(linkedRecord), password: '', ...passwordSecurity }, stripped: true },
    { record: { ...baseRecord, password: '', ...passwordSecurity }, stripped: false },
    { record: { ...stripEvent(baseRecord), password: '', ...passwordSecurity }, stripped: true },
    { record: linkedRecord, stripped: false },
    { record: stripEvent(linkedRecord), stripped: true },
    { record: baseRecord, stripped: false },
    { record: stripEvent(baseRecord), stripped: true }
  ];

  // Track whether we had to drop event_date/event_key to land the
  // delivery row. The frontend uses this to surface a clear
  // "DB migration part 6 not applied" warning instead of silently
  // saving a row that won't group on /db.
  const requestedEventGrouping = !!(eventDate || eventKey);
  let eventColumnsMissing = false;

  let deliveryRows;
  let lastDeliveryError = null;
  for (const variant of recordVariants) {
    try {
      deliveryRows = await supabaseFetch(env, '/rest/v1/deliveries', {
        method: 'POST',
        headers: { Prefer: 'return=representation' },
        body: JSON.stringify(variant.record)
      });
      if (variant.stripped && requestedEventGrouping) eventColumnsMissing = true;
      break;
    } catch (error) {
      lastDeliveryError = error;
      if (!isSchemaError(error)) break;
    }
  }
  if (!deliveryRows && lastDeliveryError) throw lastDeliveryError;

  const delivery = Array.isArray(deliveryRows) ? deliveryRows[0] : deliveryRows;
  if (!delivery?.id) return json({ error: 'Delivery was not created.' }, 500);

  // Per-delivery unique link slug. The shared folder-derived
  // `baseSlug` is intentionally NOT used here: the
  // `delivery_links_service_slug_uidx` unique index on
  // (service, slug) would otherwise reject a second delivery that
  // reuses the same folder/event (e.g. a vendor delivery saved
  // after the client delivery), surfacing as a PostgREST 23505 and
  // the opaque "Database request failed" toast on /l. Suffixing the
  // per-delivery `shortCode` (already unique via
  // deliveries_short_code_uidx) makes (service, slug) unique per
  // delivery. `delivery_links.slug` is never used as a lookup or
  // display key — all link reads are by delivery_id, and public
  // routing resolves via deliveries.base_slug / short_code — so the
  // stored value is free to change without affecting any route.
  const linkSlug = `${baseSlug}-${shortCode}`;
  const rows = cleanLinks.map((link) => ({
    delivery_id: delivery.id,
    service: link.service,
    original_url: link.originalUrl,
    slug: linkSlug,
    short_path: `/${shortCode}`,
    link_done: link.link_done
  }));

  if (rows.length) {
    try {
      await supabaseFetch(env, '/rest/v1/delivery_links', {
        method: 'POST',
        headers: { Prefer: 'return=minimal' },
        body: JSON.stringify(rows)
      });
    } catch (error) {
      // The per-delivery linkSlug above should prevent the
      // (service, slug) unique collision, but if a 23505 still
      // occurs, log an explicit diagnostic server-side (the
      // generic user-facing message is produced by the global API
      // catch). Rethrow so behaviour is otherwise unchanged.
      if (error?.code === '23505') {
        console.warn('[deliveries-save] delivery_links unique collision (23505) on (service, slug):', linkSlug, error?.message || '');
      }
      throw error;
    }
  }

  // Cross-ref fallback: when there is a linked invoice, stamp its
  // invoice_data jsonb blob with delivery_id + event_key so /db can
  // recover the grouping even when the delivery row could not store
  // the event_key column itself (e.g. pre-part-6 schema). This is a
  // best-effort patch — failures here never block the save response.
  if (linkedInvoice?.id) {
    try {
      const existingData = (linkedInvoice.invoice_data && typeof linkedInvoice.invoice_data === 'object') ? linkedInvoice.invoice_data : {};
      const patchedData = { ...existingData };
      let dirty = false;
      if (!patchedData.delivery_id) {
        patchedData.delivery_id = delivery.id;
        dirty = true;
      }
      if (!patchedData.event_key && eventKey) {
        patchedData.event_key = eventKey;
        dirty = true;
      }
      if (dirty) {
        await supabaseFetch(env, `/rest/v1/invoices?id=eq.${encodeURIComponent(linkedInvoice.id)}`, {
          method: 'PATCH',
          headers: { Prefer: 'return=minimal' },
          body: JSON.stringify({ invoice_data: patchedData })
        });
      }
    } catch (error) {
      console.warn('[deliveries-save] cross-ref invoice_data patch failed:', error?.message || error);
    }
  }

  if (eventColumnsMissing) {
    console.warn('[deliveries-save] event_date/event_key columns missing — apply db-migration-part-6.sql');
  }

  return json({
    ok: true,
    deliveryId: delivery.id,
    deliveryUrl,
    shortCode,
    shortUrl: `/${shortCode}`,
    shortLink: `${PUBLIC_SITE}/${shortCode}`,
    password,
    generatedText,
    savedLinks: rows.length,
    ...(eventColumnsMissing ? { migrationMissing: 'deliveries.event_key' } : {})
  });
}

async function handleAdminOpenDelivery(request, env) {
  if (!(await verifyAdminSessionCookie(request, env))) return json({ error: 'Unauthorized.' }, 401);
  const url = new URL(request.url);
  const id = String(url.searchParams.get('id') || '').trim();
  if (!id) return json({ error: 'Missing delivery id.' }, 400);

  const delivery = await getDeliveryById(env, id);
  if (!delivery?.id) return json({ error: 'Delivery not found.' }, 404);

  const shortCode = deliveryShortCode(delivery) || explicitShortCode(delivery);
  if (!shortCode) return json({ error: 'Delivery short link is unavailable.' }, 404);

  return new Response(null, {
    status: 302,
    headers: {
      Location: `/${encodeURIComponent(shortCode)}`,
      'Set-Cookie': await createGallerySessionCookie(env, delivery.id),
      'Cache-Control': 'no-store'
    }
  });
}

async function handleUnlock(request, env) {
  // Body is parsed up-front so we can branch on whether this is a real
  // password attempt (counts toward the gallery rate limit) or an
  // empty-password probe (does not — see below).
  const body = await request.json().catch(() => ({}));
  const lookup = String(body.slug || body.shortCode || '').trim();
  const password = String(body.password || '').trim();

  // Admin-session bypass.
  //
  // /db opens View Links straight to /<short>, which lands on the
  // gallery page. Authenticated admins should not need to remember
  // each delivery's gallery password; if the request carries a valid
  // signed admin session cookie (HttpOnly, set by /api/admin-check),
  // we skip gallery-password verification and the per-IP gallery
  // lockout entirely. The cookie is HttpOnly so it never reaches the
  // frontend — the server is the only thing that can read it.
  //
  // Public visitors are unaffected: with no admin cookie they go down
  // the existing password / rate-limit path.
  const adminBypass = await verifyAdminSessionCookie(request, env);

  // Rate-limit only real password attempts. Two reasons:
  //   1. The gallery page now does an empty-password probe on mount
  //      so an authenticated admin auto-unlocks. We do not want
  //      legitimate page loads to drain the public 12/min budget.
  //   2. Empty-password requests cannot succeed (verifyGalleryPassword
  //      always rejects them), so they are not a brute-force surface.
  // Real password attempts still consume the budget exactly as before.
  if (!adminBypass && password) {
    const limited = enforceRateLimit(request, 'gallery-unlock', { limit: 12, windowMs: 60 * 1000, blockMs: 15 * 60 * 1000 });
    if (limited) return limited;
  }

  const delivery = await getDeliveryByLookup(env, lookup);
  if (!delivery) return json({ error: 'Delivery not found.' }, 404);

  if (adminBypass) {
    // Distinct event so admin previews don't pollute the
    // password_success / opens stats with operator-side traffic.
    await insertLog(env, request, delivery.id, 'admin_unlock');
  } else {
    const galleryBypass = await verifyGallerySessionCookie(request, env, delivery.id);
    if (galleryBypass && !password) {
      const payload = await publicDeliveryPayload(env, delivery);
      return json({ ok: true, ...payload });
    }

    // Empty-password probe by a non-admin visitor.
    //
    // The public gate calls /api/unlock once on mount with an empty
    // password so it can render "Hello, <Title> <Client Name>"
    // before the visitor types the access key. We answer with
    // ONLY the safe public-facing metadata (title + client name —
    // the same values that already appear in the WhatsApp/IG
    // delivery message we sent the client). No links, no folder
    // name, no delivery id, no logs are written. If the metadata
    // cannot be loaded the gate falls back gracefully to "Hello".
    if (!password) {
      return json({
        ok: false,
        gate: {
          title: String(delivery.title || ''),
          clientName: String(delivery.client_name || '')
        }
      });
    }
    if (!(await verifyGalleryPassword(delivery, password))) {
      // Only count an attempt as failed when a password was actually
      // submitted. Empty-password probes return the gate metadata
      // shape above and don't add a password_failed row.
      await insertLog(env, request, delivery.id, 'password_failed');
      return json({ error: 'Wrong password.' }, 401);
    }
    await insertLog(env, request, delivery.id, 'password_success');
  }

  const payload = await publicDeliveryPayload(env, delivery);
  const headers = adminBypass ? {} : { 'Set-Cookie': await createGallerySessionCookie(env, delivery.id) };
  return json({ ok: true, ...payload }, 200, headers);
}

const ALLOWED_PUBLIC_CLICK_EVENTS = new Set([
  'button_click',
  'service_click',
  'invoice_view',
  'invoice_fullscreen',
  'invoice_download',
  'payment_bank_copy',
  'payment_bank',
  'payment_qr_download',
  'payment_qr'
]);

async function handleClick(request, env) {
  const limited = enforceRateLimit(request, 'gallery-click', { limit: 60, windowMs: 60 * 1000, blockMs: 5 * 60 * 1000 });
  if (limited) return limited;

  const body = await request.json().catch(() => ({}));
  const deliveryId = String(body.deliveryId || '').trim();
  const service = cleanLogService(body.service);
  const rawEventType = cleanLogEvent(body.eventType || body.event_type || 'button_click');
  if (!deliveryId || !service) return json({ ok: false }, 400);

  const isAdmin = await verifyAdminSessionCookie(request, env);
  const isGalleryUnlocked = isAdmin || await verifyGallerySessionCookie(request, env, deliveryId);
  if (!isGalleryUnlocked) return json({ ok: false, error: 'Unauthorized.' }, 401);

  // Never allow external callers to spoof admin_* or password_* events,
  // and skip logging admin preview clicks as client activity.
  if (isAdmin) return json({ ok: true });
  const safeEventType = ALLOWED_PUBLIC_CLICK_EVENTS.has(rawEventType) ? rawEventType : 'button_click';
  await insertLog(env, request, deliveryId, safeEventType, service);
  return json({ ok: true });
}

async function handleOpenLink(request, env) {
  const url = new URL(request.url);
  const deliveryId = String(url.searchParams.get('deliveryId') || url.searchParams.get('delivery_id') || '').trim();
  const service = cleanService(url.searchParams.get('service'));
  if (!deliveryId || !service) return new Response('Missing link.', { status: 400 });

  const isAdmin = await verifyAdminSessionCookie(request, env);
  const isGalleryUnlocked = isAdmin || await verifyGallerySessionCookie(request, env, deliveryId);
  if (!isGalleryUnlocked) {
    const delivery = await getDeliveryById(env, deliveryId).catch(() => null);
    const shortCode = delivery ? (deliveryShortCode(delivery) || explicitShortCode(delivery)) : '';
    if (shortCode) {
      return new Response(null, {
        status: 302,
        headers: {
          Location: `/${encodeURIComponent(shortCode)}`,
          'Cache-Control': 'no-store'
        }
      });
    }
    return new Response('Unauthorized. Please unlock the delivery page first.', { status: 401 });
  }

  const rows = await supabaseFetch(
    env,
    `/rest/v1/delivery_links?select=*&delivery_id=eq.${encodeURIComponent(deliveryId)}&service=eq.${encodeURIComponent(service)}&limit=1`
  ).catch(() => []);
  const row = Array.isArray(rows) ? rows[0] : rows;
  const target = String(row?.original_url || '').trim();
  if (!target) return new Response('Link unavailable.', { status: 404 });

  if (!isAdmin) {
    await insertLog(env, request, deliveryId, 'service_click', service);
  }
  return new Response(null, {
    status: 302,
    headers: {
      Location: target,
      'Cache-Control': 'no-store'
    }
  });
}

async function handleDbSearch(request, env) {
  const url = new URL(request.url);
  const password = url.searchParams.get('password') || '';
  if (!(await verifyAdminRequest(request, env, password))) return json({ error: 'Unauthorized.' }, 401);

  const q = (url.searchParams.get('q') || '').trim().toLowerCase();

  // Parallelize the four independent top-level reads. Each call hits
  // a different Supabase table and none depend on each other, so the
  // total wall time drops from sum-of-latencies to max-of-latencies.
  const tolerantSupabase = async (path) => {
    try {
      const rows = await supabaseFetch(env, path);
      return Array.isArray(rows) ? rows : [];
    } catch (error) {
      if (isSchemaError(error)) return [];
      throw error;
    }
  };

  const [allDeliveries, allInvoices, clientRows, allPaymentProofs] = await Promise.all([
    supabaseFetch(env, '/rest/v1/deliveries?select=*&order=created_at.desc&limit=200')
      .then((rows) => Array.isArray(rows) ? rows : []),
    tolerantSupabase('/rest/v1/invoices?select=*&order=updated_at.desc&limit=200'),
    fetchClients(env),
    tolerantSupabase('/rest/v1/payment_proofs?select=*&order=uploaded_at.asc&limit=1000'),
  ]);

  // Delivery-scoped reads (links + access logs) depend on the
  // delivery id list, so they wait on the deliveries query — but
  // the two queries themselves run in parallel.
  const ids = allDeliveries.map((d) => d.id);
  let links = [];
  let logs = [];
  if (ids.length) {
    const inList = ids.join(',');
    [links, logs] = await Promise.all([
      supabaseFetch(env, `/rest/v1/delivery_links?select=*&delivery_id=in.(${inList})&order=created_at.asc`)
        .then((rows) => Array.isArray(rows) ? rows : []),
      supabaseFetch(env, `/rest/v1/delivery_access_logs?select=*&delivery_id=in.(${inList})&order=created_at.desc&limit=1000`)
        .then((rows) => Array.isArray(rows) ? rows : []),
    ]);
  }

  // External IP/ISP enrichment dropped from the dashboard load payload entirely;
  // logs still carry ip_address / country / city verbatim.

  // Group links and logs by delivery_id once so the items.map below is O(N)
  const linksByDelivery = new Map();
  for (const link of links) {
    const id = String(link?.delivery_id || '');
    if (!id) continue;
    let bucket = linksByDelivery.get(id);
    if (!bucket) { bucket = []; linksByDelivery.set(id, bucket); }
    bucket.push(link);
  }
  const logsByDelivery = new Map();
  for (const log of logs) {
    const id = String(log?.delivery_id || '');
    if (!id) continue;
    let bucket = logsByDelivery.get(id);
    if (!bucket) { bucket = []; logsByDelivery.set(id, bucket); }
    bucket.push(log);
  }

  const paymentProofsByInvoice = new Map();
  for (const proof of allPaymentProofs) {
    const invoiceId = String(proof?.invoice_id || '').trim();
    if (!invoiceId) continue;
    let bucket = paymentProofsByInvoice.get(invoiceId);
    if (!bucket) { bucket = []; paymentProofsByInvoice.set(invoiceId, bucket); }
    bucket.push({
      ...proof,
      image_url: `/api/payment-proof-image?id=${encodeURIComponent(proof.id)}`
    });
  }

  const invoiceRows = q
    ? allInvoices.filter((inv) => [inv.client_name, inv.client_contact, inv.status, inv.invoice_date, inv.event_date, inv.venue, inv.created_at, inv.updated_at, dateSearchTokens(inv.event_date), dateSearchTokens(inv.invoice_date)].join(' ').toLowerCase().includes(q))
    : allInvoices;

  const latestInvoiceByClient = latestByClientKey(allInvoices);
  const latestDeliveryByClient = latestByClientKey(allDeliveries);
  const invoiceById = new Map();
  const invoiceByDeliveryId = new Map();
  for (const inv of allInvoices) {
    const invId = String(inv?.id || '').trim();
    if (invId) invoiceById.set(invId, inv);
    const data = (inv?.invoice_data && typeof inv.invoice_data === 'object') ? inv.invoice_data : {};
    const deliveryId = String(data.delivery_id || '').trim();
    if (deliveryId && !invoiceByDeliveryId.has(deliveryId)) {
      invoiceByDeliveryId.set(deliveryId, inv);
    }
  }

  const items = await Promise.all(allDeliveries.map(async (d) => {
    const key = String(d.id);
    const dl = linksByDelivery.get(key) || [];
    const lg = logsByDelivery.get(key) || [];
    const adminLogs = lg.filter((log) => String(log?.event_type || '').startsWith('admin_'));
    const isPairedAdminPageView = (log) => {
      if (String(log?.event_type || '') !== 'page_view') return false;
      const logTime = new Date(log?.created_at || '').getTime();
      if (Number.isNaN(logTime)) return false;
      const ip = String(log?.ip_address || '');
      return adminLogs.some((adminLog) => {
        if (ip && String(adminLog?.ip_address || '') !== ip) return false;
        const adminTime = new Date(adminLog?.created_at || '').getTime();
        return !Number.isNaN(adminTime) && Math.abs(adminTime - logTime) <= 60 * 1000;
      });
    };
    const publicLogs = lg.filter((log) => {
      const type = String(log?.event_type || '');
      return !type.startsWith('admin_') && !isPairedAdminPageView(log);
    });
    let clicks = 0;
    let opens = 0;
    for (const log of publicLogs) {
      const type = log?.event_type;
      if (type === 'page_view' || type === 'password_success') opens += 1;
      else if (type !== 'admin_unlock' && type !== 'password_failed') clicks += 1;
    }
    const shortCode = deliveryShortCode(d);
    const shortPath = shortCode ? `/${shortCode}` : '';
    const displayPassword = await deliveryPasswordForDisplay(d, env);
    const deliveryDoneBool = !!d.delivery_done;
    // Rebuild generated messages from canonical delivery fields so
    // older rows pick up template changes without a manual repair.
    const messageInput = displayPassword && shortCode
      ? deliveryMessageInput({
          title: d.title ?? 'Ms.',
          clientName: d.client_name,
          folderName: d.folder_name,
          eventDate: d.event_date,
          shortCode,
          password: displayPassword,
          deliveryDone: deliveryDoneBool
        })
      : null;
    const generatedText = messageInput
      ? buildDeliveryMessage(messageInput)
      : stripPasswordHistoryMarker(d.generated_text_whatsapp);
    const generatedTextIg = messageInput
      ? generatedText
      : stripPasswordHistoryMarker(d.generated_text_instagram);
    const passwordHistory = deliveryPasswordHistory(d);
    // Effective event grouping key.
    //
    // Preferred source is the typed column (deliveries.event_key,
    // populated when db-migration-part-6.sql is applied). If the
    // column is missing/empty we recover the link via the cross-ref
    // we stamped into the linked invoice's invoice_data jsonb on
    // save (handleSave below): any invoice whose invoice_data
    // .delivery_id matches this delivery contributes its own id as
    // the effective event_key, so /db's grouping pass on the client
    // can still merge the invoice + delivery into a single row.
    const typedEventKey = String(d.event_key || '').trim();
    const linkedInvoiceForDelivery = invoiceByDeliveryId.get(key) || invoiceById.get(typedEventKey) || null;
    const linkedInvoiceData = (linkedInvoiceForDelivery?.invoice_data && typeof linkedInvoiceForDelivery.invoice_data === 'object')
      ? linkedInvoiceForDelivery.invoice_data
      : {};
    const linkedInvoiceType = String(
      linkedInvoiceForDelivery?.invoice_type
        || linkedInvoiceData.invoiceType
        || d.type
        || ''
    ).trim().toLowerCase() === 'vendor' ? 'vendor' : 'client';
    let effectiveEventKey = typedEventKey;
    if (!effectiveEventKey) {
      if (linkedInvoiceForDelivery?.id) effectiveEventKey = String(linkedInvoiceForDelivery.id);
    }
    return {
      id: d.id,
      type: linkedInvoiceType,
      title: d.title,
      client_id: d.client_id || '',
      client_name: d.client_name,
      folder_name: d.folder_name,
      base_slug: d.base_slug,
      password: displayPassword,
      delivery_year: d.delivery_year,
      delivery_month: d.delivery_month,
      generated_text_whatsapp: generatedText,
      generated_text_instagram: generatedTextIg,
      created_at: d.created_at,
      event_date: d.event_date || '',
      // Completion flag (db-migration-part-8). Coerced to a real
      // boolean so a missing column on a legacy schema reads as
      // false rather than leaking null into the dashboard.
      delivery_done: deliveryDoneBool,
      password_history: passwordHistory,
      event_key: effectiveEventKey,
      delivery_url: shortPath,
      short_code: shortCode,
      short_url: shortPath,
      needs_secure_repair: !shortCode,
      gallery_code: galleryCodeFromSlug(d.base_slug),
      related_invoice: invoiceSummary(relatedByClientKey(d, latestInvoiceByClient)),
      links: dl,
      stats: { opens, clicks, logs: publicLogs.slice(0, 50) }
    };
  }));

  const invoicesWithRelated = invoiceRows.map((inv) => {
    // Effective event grouping key for invoices. Same priority as
    // deliveries above: the typed column wins, falling back to the
    // jsonb mirror that normalizeInvoicePayload writes on every
    // save. This keeps /db grouping correct even when the
    // invoices.event_key column has been stripped at save time
    // (pre-part-6 schemas).
    const data = (inv?.invoice_data && typeof inv.invoice_data === 'object') ? inv.invoice_data : {};
    const effectiveEventKey = String(inv.event_key || data.event_key || '').trim();
    return {
      ...inv,
      event_key: effectiveEventKey,
      invoice_type: String(inv.invoice_type || data.invoiceType || '').trim().toLowerCase() === 'vendor' ? 'vendor' : 'client',
      payment_proofs: paymentProofsByInvoice.get(String(inv.id || '')) || [],
      related_delivery: deliverySummary(relatedByClientKey(inv, latestDeliveryByClient))
    };
  });

  // Clients is derived from client records, invoices, and deliveries.
  const clients = buildClientSummaries(clientRows, allInvoices, allDeliveries, q);

  return json({ ok: true, items, invoices: invoicesWithRelated, clients });
}


async function handleClientSave(request, env) {
  const body = await request.json().catch(() => ({}));
  const password = String(body.password || '').trim();
  if (!(await verifyAdminRequest(request, env, password))) return json({ error: 'Unauthorized.' }, 401);

  const currentId = String(body.id || body.client_id || '').trim();
  const fields = cleanClientPayload(body);
  if (!fields.name || !fields.normalized_name) return json({ error: 'Client name is required.' }, 400);

  // Duplicate detection: a duplicate has the same normalized_name
  // AND the same human-readable contact as the payload. Instead of
  // blocking the save with 409 (which is what the previous version
  // did and what the Amanda/Amanda W bug report tripped on), we
  // resolve the conflict by merging:
  //
  //   • currentId is empty / 'legacy:*'  → adopt the duplicate as
  //     the target. PATCH the duplicate row with the new fields and
  //     attach the operator's invoice/delivery ids to it. This is
  //     the case where a legacy:<name> bucket on /db is being
  //     promoted to a real client row that already exists.
  //
  //   • currentId is a real client row  → merge the duplicate INTO
  //     currentId. Reassign the duplicate's invoice/delivery
  //     rows to currentId, drop the duplicate client row, then
  //     PATCH currentId with the new fields. The surviving client
  //     row is currentId so the operator's stable selection
  //     identity in the UI doesn't move under their feet.
  //
  // Same-id matches (the duplicate IS the current row) are filtered
  // out by findDuplicateClient itself.
  const duplicate = await findDuplicateClient(env, fields, currentId);
  let targetClientId = '';
  let mergeSourceId = '';
  if (duplicate) {
    if (!currentId || currentId.startsWith('legacy:')) {
      targetClientId = String(duplicate.id);
    } else {
      targetClientId = currentId;
      mergeSourceId = String(duplicate.id);
    }
  } else if (currentId && !currentId.startsWith('legacy:')) {
    targetClientId = currentId;
  }

  const clientBody = {
    title: fields.title,
    name: fields.name,
    contact: fields.contact,
    normalized_name: fields.normalized_name,
    updated_at: new Date().toISOString()
  };

  let clientRows;
  if (targetClientId) {
    clientRows = await supabaseFetch(env, `/rest/v1/clients?id=eq.${encodeURIComponent(targetClientId)}`, {
      method: 'PATCH',
      headers: { Prefer: 'return=representation' },
      body: JSON.stringify(clientBody)
    });
  } else {
    clientRows = await supabaseFetch(env, '/rest/v1/clients', {
      method: 'POST',
      headers: { Prefer: 'return=representation' },
      body: JSON.stringify(clientBody)
    });
  }

  const client = Array.isArray(clientRows) ? clientRows[0] : clientRows;
  if (!client?.id) return json({ error: 'Client was not saved.' }, 500);
  const clientId = String(client.id);

  const invoicePayload = {
    client_title: fields.title,
    client_name: fields.name,
    client_contact: fields.contact
  };
  const deliveryPayload = {
    title: fields.title,
    client_name: fields.name
  };

  // Helper to fetch rows by client_id or explicit id list so we can
  // separate client-scoped rows from vendor-scoped rows before patching.
  // Vendor invoices (invoice_type === 'vendor') and vendor deliveries
  // (type === 'vendor' or empty honorific title) share the parent
  // client_id for event grouping, so we must ONLY update their client_id
  // pointer and NEVER overwrite their vendor client_name or title.
  const fetchCandidateRows = async (table, ownerIds = [], extraIds = []) => {
    const byId = new Map();
    for (const ownerId of ownerIds.filter(Boolean)) {
      try {
        const rows = await supabaseFetch(env, `/rest/v1/${table}?select=*&client_id=eq.${encodeURIComponent(ownerId)}`);
        for (const r of (Array.isArray(rows) ? rows : [])) {
          if (r?.id) byId.set(String(r.id), r);
        }
      } catch (error) {
        if (!isSchemaError(error)) throw error;
      }
    }
    const cleanExtra = uniqueIds(extraIds);
    if (cleanExtra.length) {
      try {
        const rows = await supabaseFetch(env, `/rest/v1/${table}?select=*&id=in.(${inFilter(cleanExtra)})`);
        for (const r of (Array.isArray(rows) ? rows : [])) {
          if (r?.id) byId.set(String(r.id), r);
        }
      } catch (error) {
        if (!isSchemaError(error)) throw error;
      }
    }
    return [...byId.values()];
  };

  const ownerClientIds = [clientId, ...(mergeSourceId && mergeSourceId !== clientId ? [mergeSourceId] : [])];
  const [candidateInvoices, candidateDeliveries] = await Promise.all([
    fetchCandidateRows('invoices', ownerClientIds, body.invoiceIds),
    fetchCandidateRows('deliveries', ownerClientIds, body.deliveryIds),
  ]);

  const vendorDeliveryIdsFromInvoices = new Set();
  const vendorEventKeys = new Set();
  const clientScopedInvoiceIds = [];
  const vendorScopedInvoiceIds = [];

  for (const inv of candidateInvoices) {
    const invId = String(inv?.id || '');
    if (!invId) continue;
    if (invoiceRecordType(inv) === 'vendor') {
      vendorScopedInvoiceIds.push(invId);
      const data = inv?.invoice_data && typeof inv.invoice_data === 'object' ? inv.invoice_data : {};
      if (data.delivery_id) vendorDeliveryIdsFromInvoices.add(String(data.delivery_id));
      const ek = String(inv.event_key || data.event_key || '').trim();
      if (ek) vendorEventKeys.add(ek);
    } else {
      clientScopedInvoiceIds.push(invId);
    }
  }

  const clientScopedDeliveryIds = [];
  const vendorScopedDeliveryIds = [];
  for (const del of candidateDeliveries) {
    const delId = String(del?.id || '');
    if (!delId) continue;
    const isVendorDel =
      String(del?.type || '').trim().toLowerCase() === 'vendor'
      || String(del?.title ?? 'Ms.').trim() === ''
      || vendorDeliveryIdsFromInvoices.has(delId)
      || (del?.event_key && vendorEventKeys.has(String(del.event_key).trim()) && normalizeClientName(del.client_name) !== fields.normalized_name);
    if (isVendorDel) {
      vendorScopedDeliveryIds.push(delId);
    } else {
      clientScopedDeliveryIds.push(delId);
    }
  }

  const [patchedClientInvoices, patchedVendorInvoices, patchedClientDeliveries, patchedVendorDeliveries] = await Promise.all([
    clientScopedInvoiceIds.length ? patchRowsByIds(env, 'invoices', clientScopedInvoiceIds, invoicePayload, clientId) : [],
    vendorScopedInvoiceIds.length ? patchRowsByIds(env, 'invoices', vendorScopedInvoiceIds, {}, clientId) : [],
    clientScopedDeliveryIds.length ? patchRowsByIds(env, 'deliveries', clientScopedDeliveryIds, deliveryPayload, clientId) : [],
    vendorScopedDeliveryIds.length ? patchRowsByIds(env, 'deliveries', vendorScopedDeliveryIds, {}, clientId) : [],
  ]);

  if (mergeSourceId && mergeSourceId !== clientId) {
    await supabaseFetch(env, `/rest/v1/clients?id=eq.${encodeURIComponent(mergeSourceId)}`, {
      method: 'DELETE',
      headers: { Prefer: 'return=minimal' }
    }).catch((error) => {
      if (!isSchemaError(error)) console.warn('[clients] merge reap failed:', error?.message || error);
    });
  }

  const invoiceIds = new Set([...patchedClientInvoices, ...patchedVendorInvoices].map((row) => String(row.id || '')).filter(Boolean));
  const deliveryIds = new Set([...patchedClientDeliveries, ...patchedVendorDeliveries].map((row) => String(row.id || '')).filter(Boolean));

  return json({
    ok: true,
    client,
    merged: !!mergeSourceId,
    updated: {
      invoices: invoiceIds.size,
      deliveries: deliveryIds.size
    }
  });
}

async function handleDbDelete(request, env) {
  const body = await request.json();
  const password = String(body.password || '').trim();
  const id = String(body.id || '').trim();
  if (!(await verifyAdminRequest(request, env, password))) return json({ error: 'Unauthorized.' }, 401);
  if (!id) return json({ error: 'Missing record id.' }, 400);

  await supabaseFetch(env, `/rest/v1/delivery_access_logs?delivery_id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: { Prefer: 'return=minimal' }
  }).catch(() => {});
  await supabaseFetch(env, `/rest/v1/delivery_links?delivery_id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: { Prefer: 'return=minimal' }
  }).catch(() => {});
  await supabaseFetch(env, `/rest/v1/deliveries?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: { Prefer: 'return=minimal' }
  });

  return json({ ok: true });
}

async function handleDbClearLogs(request, env) {
  const body = await request.json();
  const password = String(body.password || '').trim();
  const id = String(body.id || '').trim();
  if (!(await verifyAdminRequest(request, env, password))) return json({ error: 'Unauthorized.' }, 401);
  if (!id) return json({ error: 'Missing record id.' }, 400);

  // Per-card delete: when the caller passes explicit log ids we delete
  // ONLY those rows, and ALWAYS scope the delete to this delivery_id so
  // a stray/forged id can never reach another delivery's logs. With no
  // ids we fall back to clearing this delivery's whole timeline.
  const logIds = Array.isArray(body.logIds)
    ? [...new Set(body.logIds.map((value) => String(value || '').trim()).filter(Boolean))]
    : [];
  const deliveryFilter = `delivery_id=eq.${encodeURIComponent(id)}`;

  if (Array.isArray(body.logIds) && !logIds.length) {
    return json({ error: 'No valid log ids supplied.' }, 400);
  }

  const path = logIds.length
    ? `/rest/v1/delivery_access_logs?${deliveryFilter}&id=in.(${logIds.map((value) => encodeURIComponent(value)).join(',')})`
    : `/rest/v1/delivery_access_logs?${deliveryFilter}`;

  await supabaseFetch(env, path, {
    method: 'DELETE',
    headers: { Prefer: 'return=minimal' }
  });

  return json({ ok: true });
}

async function handleDbRepairDelivery(request, env) {
  const body = await request.json().catch(() => ({}));
  const password = String(body.password || '').trim();
  const id = String(body.id || body.deliveryId || '').trim();
  const rotatePassword = Boolean(body.rotatePassword);
  // Custom password path. When the operator sets a specific password
  // via the pencil control, body.customPassword carries it. Validate
  // with the same minimal bounds the gallery unlock expects: trim
  // whitespace, reject empty, cap length so the hash input stays sane.
  const customPasswordRequested = body.customPassword !== undefined && body.customPassword !== null;
  const customPassword = customPasswordRequested ? String(body.customPassword).trim() : '';
  if (!(await verifyAdminRequest(request, env, password))) return json({ error: 'Unauthorized.' }, 401);
  if (!id) return json({ error: 'Missing delivery id.' }, 400);
  if (customPasswordRequested) {
    if (!customPassword) return json({ error: 'Password cannot be empty.' }, 400);
    if (customPassword.length > 72) return json({ error: 'Use 72 characters or fewer.' }, 400);
  }

  const rows = await supabaseFetch(
    env,
    `/rest/v1/deliveries?select=*&id=eq.${encodeURIComponent(id)}&limit=1`
  );
  const delivery = Array.isArray(rows) ? rows[0] : rows;
  if (!delivery?.id) return json({ error: 'Delivery not found.' }, 404);

  const existingCode = deliveryShortCode(delivery) || explicitShortCode(delivery);
  const shortCode = existingCode.length === SHORT_CODE_LENGTH
    ? existingCode
    : await uniqueShortCode(env, {
        deliveryId: delivery.id,
        baseSlug: delivery.base_slug || '',
        folderName: delivery.folder_name || '',
        clientName: delivery.client_name || '',
        title: delivery.title || ''
      });

  let displayPassword = rotatePassword ? '' : await deliveryPasswordForDisplay(delivery, env);
  if (customPassword) displayPassword = customPassword;

  const hasStoredHash = !!(String(delivery.password_hash || '').trim() && String(delivery.password_salt || '').trim());
  if (!displayPassword && hasStoredHash && !rotatePassword) {
    return json({
      error: 'This delivery already has a hashed password but no recoverable display password. Create a fresh delivery link instead.'
    }, 409);
  }
  if (!displayPassword) {
    displayPassword = await generateGalleryPassword({
      deliveryId: delivery.id,
      baseSlug: delivery.base_slug || '',
      folderName: delivery.folder_name || '',
      clientName: delivery.client_name || '',
      title: delivery.title || ''
    }, shortCode);
  }

  // Password history is no longer grown here (the View Links history
  // UI and restore flow were removed). Any existing history value is
  // preserved verbatim so stored data and the generated-text marker
  // round-trip unchanged, but refresh/custom-password no longer add
  // new entries.
  const password_history = deliveryPasswordHistory(delivery);

  const deliveryDone = !!delivery.delivery_done;
  const messageInput = deliveryMessageInput({
    title: delivery.title ?? 'Ms.',
    clientName: delivery.client_name || '',
    folderName: delivery.folder_name,
    eventDate: delivery.event_date,
    shortCode,
    password: displayPassword,
    deliveryDone
  });
  const generatedText = buildDeliveryMessage(messageInput);
  const generatedTextIg = generatedText;
  const redactedMessage = buildDeliveryMessage({ ...messageInput, password: '[protected]' });
  const storedGeneratedTextIg = await withPasswordHistoryMarker(redactedMessage, password_history, displayPassword, env);
  const patch = {
    short_code: shortCode,
    password: '',
    generated_text_whatsapp: redactedMessage,
    generated_text_instagram: storedGeneratedTextIg,
    password_history
  };

  if (!hasStoredHash || rotatePassword || customPassword) {
    Object.assign(patch, await hashGalleryPassword(displayPassword));
  }

  let repairedRows;
  try {
    repairedRows = await supabaseFetch(
      env,
      `/rest/v1/deliveries?id=eq.${encodeURIComponent(id)}`,
      {
        method: 'PATCH',
        headers: { Prefer: 'return=representation' },
        body: JSON.stringify(patch)
      }
    );
  } catch (error) {
    if (!isSchemaError(error)) throw error;
    delete patch.password_history;
    repairedRows = await supabaseFetch(
      env,
      `/rest/v1/deliveries?id=eq.${encodeURIComponent(id)}`,
      {
        method: 'PATCH',
        headers: { Prefer: 'return=representation' },
        body: JSON.stringify(patch)
      }
    );
  }

  const repaired = Array.isArray(repairedRows) ? repairedRows[0] : repairedRows;

  await supabaseFetch(
    env,
    `/rest/v1/delivery_links?delivery_id=eq.${encodeURIComponent(id)}`,
    {
      method: 'PATCH',
      headers: { Prefer: 'return=minimal' },
      body: JSON.stringify({ short_path: `/${shortCode}` })
    }
  ).catch((error) => {
    if (!isSchemaError(error)) throw error;
  });

  return json({
    ok: true,
    shortCode,
    shortUrl: `/${shortCode}`,
    shortLink: `${PUBLIC_SITE}/${shortCode}`,
    password: displayPassword,
    generatedText,
    delivery: {
      ...delivery,
      ...(repaired || {}),
      password: displayPassword,
      short_code: shortCode,
      delivery_url: `/${shortCode}`,
      short_url: `/${shortCode}`,
      generated_text_whatsapp: generatedText,
      generated_text_instagram: generatedTextIg,
      password_history,
      needs_secure_repair: false
    }
  });
}

async function handleDbUpdateDelivery(request, env) {
  const body = await request.json().catch(() => ({}));
  const password = String(body.password || '').trim();
  const id = String(body.id || body.deliveryId || '').trim();
  if (!(await verifyAdminRequest(request, env, password))) return json({ error: 'Unauthorized.' }, 401);
  if (!id) return json({ error: 'Missing delivery id.' }, 400);

  const rows = await supabaseFetch(
    env,
    `/rest/v1/deliveries?select=*&id=eq.${encodeURIComponent(id)}&limit=1`
  );
  const delivery = Array.isArray(rows) ? rows[0] : rows;
  if (!delivery?.id) return json({ error: 'Delivery not found.' }, 404);

  // Done-toggle path. A request carrying `deliveryDone` flips the
  // delivery-level completion flag and mirrors that state onto all
  // existing delivery_links rows. This keeps public link readiness
  // controlled by one top-level checkmark instead of per-service
  // "Done" checkboxes.
  if (body.deliveryDone !== undefined) {
    const nextDone = body.deliveryDone === true
      || body.deliveryDone === 'true'
      || body.deliveryDone === 1
      || body.deliveryDone === '1';
    try {
      const displayPassword = await deliveryPasswordForDisplay(delivery, env);
      const shortCode = deliveryShortCode(delivery) || explicitShortCode(delivery) || '';
      const messageInput = deliveryMessageInput({
        title: delivery.title ?? 'Ms.',
        clientName: delivery.client_name || '',
        folderName: delivery.folder_name,
        eventDate: delivery.event_date,
        shortCode,
        password: displayPassword,
        deliveryDone: nextDone
      });
      const generatedText = buildDeliveryMessage(messageInput);
      const generatedTextIg = generatedText;
      const redactedMessage = buildDeliveryMessage({ ...messageInput, password: '[protected]' });
      const passwordHistory = deliveryPasswordHistory(delivery);
      const storedGeneratedTextIg = await withPasswordHistoryMarker(redactedMessage, passwordHistory, displayPassword, env);

      const patched = await supabaseFetch(env, `/rest/v1/deliveries?id=eq.${encodeURIComponent(id)}`, {
        method: 'PATCH',
        headers: { Prefer: 'return=representation' },
        body: JSON.stringify({ delivery_done: nextDone, generated_text_whatsapp: redactedMessage, generated_text_instagram: storedGeneratedTextIg })
      });
      const patchedRow = Array.isArray(patched) ? patched[0] : patched;
      let patchedLinks = [];
      try {
        patchedLinks = await supabaseFetch(env, `/rest/v1/delivery_links?delivery_id=eq.${encodeURIComponent(id)}`, {
          method: 'PATCH',
          headers: { Prefer: 'return=representation' },
          body: JSON.stringify({ link_done: nextDone })
        });
      } catch (linkError) {
        if (!isSchemaError(linkError)) throw linkError;
      }
      return json({
        ok: true,
        delivery: {
          ...delivery,
          ...(patchedRow || {}),
          delivery_done: nextDone,
          generated_text_instagram: generatedTextIg,
          password_history: passwordHistory,
          links: Array.isArray(patchedLinks) ? patchedLinks : []
        }
      });
    } catch (error) {
      if (!isSchemaError(error)) throw error;
      // The column is missing on this (un-migrated) schema. Surface
      // a clear, actionable error rather than silently no-op'ing.
      return json({ error: 'delivery_done column missing. Apply db-migration-part-8.sql.' }, 400);
    }
  }

  // Optional delivery metadata PATCH. Folder and event date edits
  // do not regenerate base_slug, short_code, or password — those are
  // owned by Repair Secure Link / Regenerate Password. If a column
  // is missing on a legacy schema we swallow the schema error so
  // the link rebuild still succeeds.
  let updatedFolderName = String(delivery.folder_name || '');
  let updatedEventDate = String(delivery.event_date || '');
  const deliveryPatch = {};
  const folderNameRaw = body.folderName ?? body.folder_name;
  if (folderNameRaw !== undefined && folderNameRaw !== null) {
    const trimmedFolder = String(folderNameRaw).trim();
    if (trimmedFolder && trimmedFolder !== String(delivery.folder_name || '').trim()) {
      deliveryPatch.folder_name = trimmedFolder;
      updatedFolderName = trimmedFolder;
    }
  }
  const eventDateRaw = body.eventDate ?? body.event_date;
  if (eventDateRaw !== undefined && eventDateRaw !== null) {
    const trimmedEventDate = String(eventDateRaw).trim();
    if (trimmedEventDate && !/^\d{4}-\d{2}-\d{2}$/.test(trimmedEventDate)) {
      return json({ error: 'Event Date must be YYYY-MM-DD.' }, 400);
    }
    const nextEventDate = trimmedEventDate || null;
    if (String(nextEventDate || '') !== String(delivery.event_date || '').trim()) {
      deliveryPatch.event_date = nextEventDate;
      updatedEventDate = String(nextEventDate || '');
    }
  }

  // Optional vendor-name edit. Edit Links exposes a Vendor Name field
  // only for vendor-scoped deliveries. Older delivery rows do not carry
  // an explicit type, so use the exact linked invoice when available;
  // an empty honorific alone is never enough to classify a delivery as
  // vendor. base_slug / short_code / public routing are untouched.
  const vendorNameRaw = body.clientName ?? body.client_name ?? body.vendorName;
  const linkedInvoiceForEdit = vendorNameRaw === undefined || vendorNameRaw === null
    ? null
    : await findInvoiceForDelivery(env, delivery).catch(() => null);
  const isVendorDelivery = deliveryInvoiceAudience(
    delivery,
    linkedInvoiceForEdit ? [linkedInvoiceForEdit] : []
  ) === 'vendor';
  const vendorName = (vendorNameRaw === undefined || vendorNameRaw === null)
    ? ''
    : String(vendorNameRaw).trim();
  let updatedClientName = String(delivery.client_name || '');
  const applyVendorName = isVendorDelivery && !!vendorName
    && vendorName !== String(delivery.client_name || '').trim();
  if (applyVendorName) {
    deliveryPatch.client_name = vendorName;
    updatedClientName = vendorName;
  }

  if (Object.keys(deliveryPatch).length) {
    try {
      const patched = await supabaseFetch(env, `/rest/v1/deliveries?id=eq.${encodeURIComponent(id)}`, {
        method: 'PATCH',
        headers: { Prefer: 'return=representation' },
        body: JSON.stringify(deliveryPatch)
      });
      const patchedRow = Array.isArray(patched) ? patched[0] : patched;
      if (patchedRow) {
        updatedFolderName = String(patchedRow.folder_name || updatedFolderName || '');
        updatedEventDate = String(patchedRow.event_date || updatedEventDate || '');
      }
    } catch (error) {
      if (!isSchemaError(error)) throw error;
      // Column missing on a legacy schema. If event_date was the
      // incompatible field, retry a plain folder rename so older DBs
      // keep the behaviour this endpoint already supported.
      if (deliveryPatch.folder_name) {
        try {
          const patched = await supabaseFetch(env, `/rest/v1/deliveries?id=eq.${encodeURIComponent(id)}`, {
            method: 'PATCH',
            headers: { Prefer: 'return=representation' },
            body: JSON.stringify({ folder_name: deliveryPatch.folder_name })
          });
          const patchedRow = Array.isArray(patched) ? patched[0] : patched;
          updatedFolderName = String(patchedRow?.folder_name || deliveryPatch.folder_name || delivery.folder_name || '');
        } catch (retryError) {
          if (!isSchemaError(retryError)) throw retryError;
          updatedFolderName = String(delivery.folder_name || '');
        }
      } else {
        updatedFolderName = String(delivery.folder_name || '');
      }
      // Drop the event-date edit and continue with the link rebuild.
      updatedEventDate = String(delivery.event_date || '');
    }
  }

  const links = Array.isArray(body.links) ? body.links : [];
  const cleanLinks = links
    .map((link) => {
      let isDone = !!delivery.delivery_done;
      if (typeof link.link_done === 'boolean') isDone = link.link_done;
      else if (typeof link.linkDone === 'boolean') isDone = link.linkDone;
      else if (typeof link.done === 'boolean') isDone = link.done;
      else if (link.link_done === 'true' || link.linkDone === 'true' || link.done === 'true') isDone = true;
      return {
        service: cleanService(link.service),
        originalUrl: normalizeUrl(link.originalUrl || link.original_url || link.url),
        link_done: isDone
      };
    })
    .filter((link) => link.service && link.originalUrl);

  await supabaseFetch(env, `/rest/v1/delivery_links?delivery_id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: { Prefer: 'return=minimal' }
  }).catch(() => {});

  const shortCode = deliveryShortCode(delivery) || explicitShortCode(delivery);
  const displayPassword = await deliveryPasswordForDisplay(delivery, env);
  const deliveryDone = !!delivery.delivery_done;
  const messageInput = displayPassword && shortCode
    ? deliveryMessageInput({
        title: delivery.title ?? 'Ms.',
        clientName: updatedClientName || delivery.client_name || '',
        folderName: updatedFolderName,
        eventDate: updatedEventDate,
        shortCode,
        password: displayPassword,
        deliveryDone
      })
    : null;
  const generatedText = messageInput
    ? buildDeliveryMessage(messageInput)
    : stripPasswordHistoryMarker(delivery.generated_text_whatsapp);
  const generatedTextIg = messageInput
    ? generatedText
    : stripPasswordHistoryMarker(delivery.generated_text_instagram);
  const redactedMessage = messageInput
    ? buildDeliveryMessage({ ...messageInput, password: '[protected]' })
    : generatedText;
  const passwordHistory = deliveryPasswordHistory(delivery);
  const storedGeneratedTextIg = await withPasswordHistoryMarker(redactedMessage, passwordHistory, displayPassword, env);

  if (redactedMessage || storedGeneratedTextIg) {
    await supabaseFetch(env, `/rest/v1/deliveries?id=eq.${encodeURIComponent(id)}`, {
      method: 'PATCH',
      headers: { Prefer: 'return=minimal' },
      body: JSON.stringify({
        generated_text_whatsapp: redactedMessage,
        generated_text_instagram: storedGeneratedTextIg
      })
    }).catch((error) => {
      if (!isSchemaError(error)) throw error;
    });
  }

  const insertedLinks = cleanLinks.length ? await supabaseFetch(env, '/rest/v1/delivery_links', {
    method: 'POST',
    headers: { Prefer: 'return=representation' },
    body: JSON.stringify(cleanLinks.map((link) => ({
      delivery_id: id,
      service: link.service,
      original_url: link.originalUrl,
      // Per-delivery unique slug (mirrors handleSave): suffix the
      // unique short_code so the (service, slug) unique index never
      // collides with another delivery reusing the same base_slug.
      // Falls back to the bare base_slug only when no short_code is
      // available (un-repaired legacy row), matching prior behaviour.
      slug: shortCode ? `${delivery.base_slug || ''}-${shortCode}` : (delivery.base_slug || ''),
      short_path: shortCode ? `/${shortCode}` : '',
      link_done: link.link_done
    })))
  }) : [];

  // Best-effort mirror of the vendor name onto the linked vendor
  // invoice so the two event-scoped copies stay in sync. Only runs
  // for a vendor delivery whose name actually changed. The invoice
  // is located using the delivery's PRE-rename fields — the in-memory
  // `delivery` row still holds the OLD client_name, so the existing
  // vendor invoice is found via delivery_id cross-ref / event_key /
  // client_id / old name. We patch ONLY client_name and ONLY when the
  // matched invoice is itself vendor-scoped, so a client invoice is
  // never touched. Any failure (no vendor invoice, schema, network)
  // is logged but never fails the Save Links request.
  if (applyVendorName) {
    try {
      const linkedInvoice = linkedInvoiceForEdit || await findInvoiceForDelivery(env, delivery);
      if (linkedInvoice?.id && invoiceRecordType(linkedInvoice) === 'vendor') {
        await supabaseFetch(env, `/rest/v1/invoices?id=eq.${encodeURIComponent(linkedInvoice.id)}`, {
          method: 'PATCH',
          headers: { Prefer: 'return=minimal' },
          body: JSON.stringify({ client_name: vendorName })
        });
      }
    } catch (error) {
      console.warn('[db-update-delivery] vendor name mirror to invoice failed:', error?.message || error);
    }
  }

  return json({
    ok: true,
    delivery: {
      ...delivery,
      client_name: updatedClientName,
      folder_name: updatedFolderName,
      event_date: updatedEventDate,
      generated_text_whatsapp: generatedText,
      generated_text_instagram: generatedTextIg,
      password_history: passwordHistory,
      links: Array.isArray(insertedLinks) ? insertedLinks : [],
    },
  });
}

async function handleDbPasswordChange(request, env) {
  const body = await request.json().catch(() => ({}));
  const password = String(body.password || '').trim();
  const nextPassword = String(body.newPassword || '').trim();
  if (!(await verifyAdminRequest(request, env, password))) return json({ error: 'Unauthorized.' }, 401);
  if (nextPassword.length < 4) return json({ error: 'Use at least 4 characters.' }, 400);
  if (nextPassword.length > 72) return json({ error: 'Use 72 characters or fewer.' }, 400);
  return json({ error: 'Admin password is managed by Cloudflare Secret. Run: npx wrangler pages secret put ADMIN_PASSWORD --project-name=starshots' }, 400);
}

// Cascade-delete a client and every record that belongs to them.
//
// Body shape (JSON):
//   { id: "<uuid> | legacy:<normalized>", name?: "<display name>", password?: "..." }
//
// Match strategy mirrors how /api/db buckets records into client
// summaries: a real client_id wins; otherwise we fall back to the
// denormalized client_name string. We delete by both filters when
// available so legacy rows missing client_id (older imports) are not
// left orphaned. Slug, password-hash, and salt logic are untouched —
// this handler only issues PostgREST DELETEs.
async function handleClientDelete(request, env) {
  const body = await request.json().catch(() => ({}));
  const password = String(body.password || '').trim();
  if (!(await verifyAdminRequest(request, env, password))) return json({ error: 'Unauthorized.' }, 401);

  const rawId = String(body.id || body.client_id || '').trim();
  const clientName = String(body.name || body.client_name || '').trim();
  const isRealId = !!rawId && !rawId.startsWith('legacy:');
  if (!isRealId && !clientName) return json({ error: 'Missing client id or name.' }, 400);

  const filters = [];
  if (isRealId) filters.push(`client_id=eq.${encodeURIComponent(rawId)}`);
  if (clientName) filters.push(`client_name=eq.${encodeURIComponent(clientName)}`);

  // Step 1: collect all delivery ids that match any filter so we can
  // clean their dependent rows (delivery_links, delivery_access_logs)
  // before deleting the deliveries themselves. delivery_links and
  // delivery_access_logs only carry delivery_id, not client_id, so we
  // cannot delete them by client filter directly.
  const deliveryIds = new Set();
  for (const filter of filters) {
    try {
      const rows = await supabaseFetch(env, `/rest/v1/deliveries?select=id&${filter}`);
      (Array.isArray(rows) ? rows : []).forEach((row) => {
        if (row?.id) deliveryIds.add(String(row.id));
      });
    } catch (error) {
      if (!isSchemaError(error)) throw error;
    }
  }

  if (deliveryIds.size > 0) {
    const inList = [...deliveryIds].map((id) => encodeURIComponent(id)).join(',');
    await supabaseFetch(env, `/rest/v1/delivery_access_logs?delivery_id=in.(${inList})`, {
      method: 'DELETE',
      headers: { Prefer: 'return=minimal' },
    }).catch(() => {});
    await supabaseFetch(env, `/rest/v1/delivery_links?delivery_id=in.(${inList})`, {
      method: 'DELETE',
      headers: { Prefer: 'return=minimal' },
    }).catch(() => {});
    await supabaseFetch(env, `/rest/v1/deliveries?id=in.(${inList})`, {
      method: 'DELETE',
      headers: { Prefer: 'return=minimal' },
    }).catch(() => {});
  }

  // Step 2: invoices also denormalize client_name, so issue one
  // DELETE per matched filter on the invoice table.
  for (const filter of filters) {
    await supabaseFetch(env, `/rest/v1/invoices?${filter}`, {
      method: 'DELETE',
      headers: { Prefer: 'return=minimal' },
    }).catch(() => {});
  }
  // Step 3: drop the canonical client row last so the per-record
  // FK ON DELETE SET NULL doesn't dirty the records we've already
  // queued for deletion. Legacy buckets have no client row to drop.
  if (isRealId) {
    await supabaseFetch(env, `/rest/v1/clients?id=eq.${encodeURIComponent(rawId)}`, {
      method: 'DELETE',
      headers: { Prefer: 'return=minimal' },
    }).catch(() => {});
  }

  return json({ ok: true });
}


function normalizeInvoicePayload(raw = {}) {
  const data = raw.invoice_data && typeof raw.invoice_data === 'object' ? { ...raw.invoice_data } : {};
  const status = ['invoice', 'deposit', 'paid'].includes(String(raw.status || '').toLowerCase()) ? String(raw.status).toLowerCase() : 'invoice';
  const cleanMoney = (v) => Math.max(0, Math.round(Number(v) || 0));
  const eventKeyRaw = String(raw.event_key || raw.eventKey || '').trim().slice(0, 80);
  const invoiceType = String(raw.invoice_type || raw.invoiceType || data.invoiceType || '').trim().toLowerCase() === 'vendor'
    ? 'vendor'
    : 'client';
  data.invoiceType = invoiceType;
  // Belt-and-suspenders: also mirror the event grouping key into the
  // invoice_data jsonb blob. The blob has always existed on the
  // invoices table, so it survives a stripped event_key column on
  // pre-part-6 schemas. handleDbSearch reads invoice_data.event_key
  // as a fallback when the column is missing/null, keeping the /db
  // grouping pass functional even when the migration hasn't been
  // applied yet. We never overwrite a non-empty existing value.
  if (eventKeyRaw && !data.event_key) data.event_key = eventKeyRaw;
  const payload = {
    client_title: String(raw.client_title ?? 'Ms.').slice(0, 20),
    client_name: String(raw.client_name || '').trim().slice(0, 160),
    client_contact: String(raw.client_contact || '').trim().slice(0, 240),
    invoice_date: String(raw.invoice_date || '').trim().slice(0, 40),
    event_date: String(raw.event_date || '').trim().slice(0, 40),
    event_time: String(raw.event_time || '').trim().slice(0, 40),
    venue: String(raw.venue || '').trim().slice(0, 240),
    status,
    grand_total: cleanMoney(raw.grand_total),
    deposit_amount: cleanMoney(raw.deposit_amount),
    paid_amount: cleanMoney(raw.paid_amount),
    balance_due: cleanMoney(raw.balance_due),
    invoice_data: data
  };
  if (eventKeyRaw) payload.event_key = eventKeyRaw;
  return payload;
}

async function handleInvoiceSave(request, env) {
  const body = await request.json();
  const password = String(body.password || '').trim();
  if (!(await verifyAdminRequest(request, env, password))) return json({ error: 'Unauthorized.' }, 401);

  const invoice = normalizeInvoicePayload(body.invoice || {});
  if (!invoice.client_name) return json({ error: 'Client name is required.' }, 400);
  const id = String((body.invoice || {}).id || '').trim();
  let existingInvoice = null;
  if (id) {
    existingInvoice = await supabaseFetch(env, `/rest/v1/invoices?select=*&id=eq.${encodeURIComponent(id)}&limit=1`)
      .then((rows) => Array.isArray(rows) ? rows[0] : rows)
      .catch(() => null);
  }
  const client = await findOrCreateClient(env, {
    title: invoice.client_title,
    name: invoice.client_name,
    contact: invoice.client_contact
  }, String(body.clientId || '').trim() || existingInvoice?.client_id || '');
  const linkedInvoice = client?.id ? { ...invoice, client_id: String(client.id) } : invoice;
  const invoiceWithoutClient = { ...invoice };
  // Schema-tolerant retry layers: stripping event_key (missing on
  // pre-part-6 schemas) and stripping client_id (missing on the
  // earliest schemas). We try the richest payload first and fall
  // back step by step on isSchemaError.
  //
  // The retained event_key still lives in invoice_data.event_key
  // (set by normalizeInvoicePayload), so even when the column is
  // stripped here the grouping key is preserved on disk and
  // handleDbSearch can recover it for /db's merge pass.
  const stripEventKey = (record) => {
    const next = { ...record };
    delete next.event_key;
    return next;
  };
  // Track whether the event_key column had to be dropped to land
  // the row. The frontend uses this to surface a clear "DB
  // migration part 6 not applied" warning instead of silently
  // creating a row that won't group on /db.
  const requestedEventKey = !!invoice.event_key;
  let eventKeyColumnMissing = false;
  // Tagged variants: each pair carries the payload + whether the
  // event_key column was stripped from it. We test all column-
  // present variants first so the column gets used whenever the
  // schema supports it.
  const variants = [
    { record: linkedInvoice, stripped: false },
    { record: stripEventKey(linkedInvoice), stripped: true },
    { record: invoiceWithoutClient, stripped: false },
    { record: stripEventKey(invoiceWithoutClient), stripped: true }
  ];

  if (id) {
    let rows;
    let lastError = null;
    for (const variant of variants) {
      try {
        rows = await supabaseFetch(env, `/rest/v1/invoices?id=eq.${encodeURIComponent(id)}`, {
          method: 'PATCH',
          headers: { Prefer: 'return=representation' },
          body: JSON.stringify(variant.record)
        });
        if (variant.stripped && requestedEventKey) eventKeyColumnMissing = true;
        lastError = null;
        break;
      } catch (error) {
        lastError = error;
        if (!isSchemaError(error)) throw error;
      }
    }
    if (lastError) throw lastError;
    const saved = Array.isArray(rows) ? rows[0] : rows;
    if (eventKeyColumnMissing) {
      console.warn('[invoices-save] event_key column missing — apply db-migration-part-6.sql');
    }
    await confirmPendingPaymentProofsForInvoice(env, saved, existingInvoice);
    return json({ ok: true, invoice: saved, ...(eventKeyColumnMissing ? { migrationMissing: 'invoices.event_key' } : {}) });
  }

  let rows;
  let lastError = null;
  for (const variant of variants) {
    try {
      rows = await supabaseFetch(env, '/rest/v1/invoices', {
        method: 'POST',
        headers: { Prefer: 'return=representation' },
        body: JSON.stringify(variant.record)
      });
      if (variant.stripped && requestedEventKey) eventKeyColumnMissing = true;
      lastError = null;
      break;
    } catch (error) {
      lastError = error;
      if (!isSchemaError(error)) throw error;
    }
  }
  if (lastError) throw lastError;
  const saved = Array.isArray(rows) ? rows[0] : rows;
  if (eventKeyColumnMissing) {
    console.warn('[invoices-save] event_key column missing — apply db-migration-part-6.sql');
  }
  await confirmPendingPaymentProofsForInvoice(env, saved, existingInvoice);
  return json({ ok: true, invoice: saved, ...(eventKeyColumnMissing ? { migrationMissing: 'invoices.event_key' } : {}) });
}

async function handleInvoiceGet(request, env) {
  if (!(await verifyAdminSessionCookie(request, env))) return json({ error: 'Unauthorized.' }, 401);
  const url = new URL(request.url);
  const id = String(url.searchParams.get('id') || '').trim();
  if (!id) return json({ error: 'Missing invoice id.' }, 400);
  const rows = await supabaseFetch(env, `/rest/v1/invoices?select=*&id=eq.${encodeURIComponent(id)}&limit=1`);
  const invoice = Array.isArray(rows) ? rows[0] : rows;
  if (!invoice) return json({ error: 'Invoice not found.' }, 404);
  return json({ ok: true, invoice });
}

async function handlePublicInvoiceGet(request, env) {
  const url = new URL(request.url);
  const lookup = String(url.searchParams.get('slug') || url.searchParams.get('shortCode') || '').trim();
  if (!lookup) return json({ error: 'Missing delivery code.' }, 400);

  const delivery = await getDeliveryByLookup(env, lookup);
  if (!delivery?.id) return json({ error: 'Delivery not found.' }, 404);

  const allowed = await verifyAdminSessionCookie(request, env)
    || await verifyGallerySessionCookie(request, env, delivery.id);
  if (!allowed) return json({ error: 'Unlock the delivery first.' }, 401);

  const invoice = await findInvoiceForDelivery(env, delivery);
  if (!invoice?.id) return json({ error: 'Invoice not found for this delivery.' }, 404);
  return json({ ok: true, invoice });
}


function cleanPaymentProofDate(value = '') {
  const raw = String(value || '').trim();
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(raw);
  if (!match) return '';
  const date = new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
  if (date.getUTCFullYear() !== Number(match[1])
    || date.getUTCMonth() !== Number(match[2]) - 1
    || date.getUTCDate() !== Number(match[3])) return '';
  return raw;
}

function cleanPaymentProofTime(value = '') {
  const match = /^([01]\d|2[0-3]):([0-5]\d)(?::[0-5]\d)?$/.exec(String(value || '').trim());
  return match ? `${match[1]}:${match[2]}` : '';
}

function cleanPaymentProofTimezoneOffset(value) {
  if (value === '' || value === null || value === undefined) return null;
  const offset = Number(value);
  return Number.isInteger(offset) && offset >= -840 && offset <= 840 ? offset : null;
}

function authoritativeInvoicePayment(invoice = {}, previousInvoice = null) {
  const data = invoice.invoice_data && typeof invoice.invoice_data === 'object' ? invoice.invoice_data : {};
  const status = String(invoice.status || '').toLowerCase();
  let candidate = null;
  let linkedPaymentId = '';

  if (status === 'paid') {
    const receipt = data.paidReceipt && typeof data.paidReceipt === 'object' ? data.paidReceipt : null;
    if (receipt && receipt.paid !== false) candidate = receipt;
  } else if (status === 'deposit') {
    const payments = (Array.isArray(data.depositPayments) ? data.depositPayments : [])
      .filter((payment) => payment?.paid);
    const previousData = previousInvoice?.invoice_data && typeof previousInvoice.invoice_data === 'object'
      ? previousInvoice.invoice_data
      : {};
    const previousById = new Map((Array.isArray(previousData.depositPayments) ? previousData.depositPayments : [])
      .map((payment) => [String(payment?.id || ''), payment]));
    const changed = payments.filter((payment) => {
      const id = String(payment?.id || '');
      const previous = id ? previousById.get(id) : null;
      if (!previous || previous?.paid !== true) return true;
      return String(previous.paidAtDate || '') !== String(payment.paidAtDate || '')
        || String(previous.paidAtTime || '') !== String(payment.paidAtTime || '')
        || Math.round(Number(previous.amount) || 0) !== Math.round(Number(payment.amount) || 0);
    });
    candidate = changed.length === 1 ? changed[0] : (changed.length === 0 && payments.length === 1 ? payments[0] : null);
    linkedPaymentId = candidate ? String(candidate.id || '').trim() : '';
  }

  const paymentDate = cleanPaymentProofDate(candidate?.paidAtDate);
  return {
    paymentDate,
    paymentTime: paymentDate ? cleanPaymentProofTime(candidate?.paidAtTime) : '',
    linkedPaymentId
  };
}

async function confirmPendingPaymentProofsForInvoice(env, invoice = {}, previousInvoice = null) {
  const invoiceId = String(invoice?.id || '').trim();
  if (!invoiceId) return;
  const status = String(invoice?.status || '').toLowerCase();
  const paidAmount = Math.max(0, Math.round(Number(invoice?.paid_amount) || 0));
  if (status !== 'paid' && !(status === 'deposit' && paidAmount > 0)) return;
  const reviewedAt = new Date().toISOString();
  const authority = authoritativeInvoicePayment(invoice, previousInvoice);
  const richPatch = {
    status: 'confirmed',
    reviewed_at: reviewedAt,
    ...(authority.paymentDate ? {
      payment_date: authority.paymentDate,
      payment_time: authority.paymentTime || null
    } : {}),
    ...(authority.linkedPaymentId ? { linked_payment_id: authority.linkedPaymentId } : {})
  };
  const path = `/rest/v1/payment_proofs?invoice_id=eq.${encodeURIComponent(invoiceId)}&status=eq.pending`;
  try {
    await supabaseFetch(env, path, {
      method: 'PATCH',
      headers: { Prefer: 'return=minimal' },
      body: JSON.stringify(richPatch)
    });
  } catch (error) {
    if (!isSchemaError(error)) throw error;
    await supabaseFetch(env, path, {
      method: 'PATCH',
      headers: { Prefer: 'return=minimal' },
      body: JSON.stringify({ status: 'confirmed', reviewed_at: reviewedAt })
    }).catch((fallbackError) => {
      if (!isSchemaError(fallbackError)) throw fallbackError;
    });
  }
}

const CLIENT_DELETABLE_PAYMENT_PROOF_STATUSES = new Set(['pending', 'rejected']);

function publicPaymentProofStatus(value = '') {
  return String(value || '').trim().toLowerCase() || 'pending';
}

function invoiceLocksPublicPaymentProofs(invoice = {}) {
  return String(invoice.status || '').trim().toLowerCase() === 'paid';
}

function invoiceHasActivePaymentRequest(invoice = {}) {
  const status = String(invoice.status || '').trim().toLowerCase();
  if (status === 'paid') return false;
  if (status !== 'deposit') return true;
  const data = invoice.invoice_data && typeof invoice.invoice_data === 'object' ? invoice.invoice_data : {};
  return data.depositAskOpen !== false;
}

function paymentProofIsForCurrentAsk(proof = {}, invoice = {}) {
  const data = invoice.invoice_data && typeof invoice.invoice_data === 'object' ? invoice.invoice_data : {};
  const openedAt = Date.parse(String(data.depositAskOpenedAt || ''));
  if (!Number.isFinite(openedAt)) return true;
  const uploadedAt = Date.parse(String(proof.uploaded_at || ''));
  return Number.isFinite(uploadedAt) && uploadedAt >= openedAt;
}

function paymentProofBelongsToDeliveryInvoice(proof = {}, delivery = {}, invoice = {}) {
  const deliveryId = String(delivery.id || '').trim();
  const invoiceId = String(invoice.id || '').trim();
  if (!deliveryId || !invoiceId || invoiceRecordType(invoice) !== 'client') return false;
  if (invoiceDeliveryScore(invoice, delivery) < 70) return false;
  if (String(proof.invoice_id || '').trim() !== invoiceId) return false;
  if (String(proof.delivery_id || '').trim() !== deliveryId) return false;

  const proofClientId = String(proof.client_id || '').trim();
  const expectedClientIds = new Set([invoice.client_id, delivery.client_id]
    .map((value) => String(value || '').trim())
    .filter(Boolean));
  if (proofClientId && expectedClientIds.size && !expectedClientIds.has(proofClientId)) return false;

  const proofEventKey = String(proof.event_key || '').trim();
  const invoiceData = invoice.invoice_data && typeof invoice.invoice_data === 'object' ? invoice.invoice_data : {};
  const expectedEventKeys = new Set([invoice.event_key, invoiceData.event_key, delivery.event_key]
    .map((value) => String(value || '').trim())
    .filter(Boolean));
  if (proofEventKey && expectedEventKeys.size && !expectedEventKeys.has(proofEventKey)) return false;

  const proofEventDate = String(proof.event_date || '').slice(0, 10);
  const expectedEventDates = new Set([invoice.event_date, delivery.event_date]
    .map((value) => String(value || '').slice(0, 10))
    .filter(Boolean));
  if (proofEventDate && expectedEventDates.size && !expectedEventDates.has(proofEventDate)) return false;
  return true;
}

function sanitizePublicPaymentProof(proof = {}) {
  const status = publicPaymentProofStatus(proof.status);
  return {
    id: String(proof.id || ''),
    status,
    payment_date: String(proof.payment_date || proof.reported_payment_date || ''),
    payment_time: cleanPaymentProofTime(proof.payment_time || proof.reported_payment_time),
    payment_provisional: CLIENT_DELETABLE_PAYMENT_PROOF_STATUSES.has(status),
    uploaded_at: String(proof.uploaded_at || ''),
    reviewed_at: proof.reviewed_at ? String(proof.reviewed_at) : null
  };
}

async function authorizePublicPaymentProofRequest(request, env, lookup = '') {
  const delivery = await getDeliveryByLookup(env, lookup);
  if (!delivery?.id) return { error: json({ error: 'Delivery not found.' }, 404) };

  const authorized = await verifyAdminSessionCookie(request, env)
    || await verifyGallerySessionCookie(request, env, delivery.id);
  if (!authorized) return { error: json({ error: 'Unlock the delivery first.' }, 401) };

  const invoice = await findInvoiceForDelivery(env, delivery);
  if (!invoice?.id || invoiceRecordType(invoice) !== 'client' || invoiceDeliveryScore(invoice, delivery) < 70) {
    return { error: json({ error: 'Payment proof is unavailable for this delivery.' }, 404) };
  }
  return { delivery, invoice };
}

async function loadPublicPaymentProofRows(env, delivery, invoice) {
  const suffix = `&invoice_id=eq.${encodeURIComponent(invoice.id)}&delivery_id=eq.${encodeURIComponent(delivery.id)}&order=uploaded_at.asc`;
  // Keep this public read narrow: optional audit/link columns must not prevent
  // the payment timestamps from being returned to the delivery UI.
  const selects = [
    'id,invoice_id,delivery_id,status,reported_payment_date,reported_payment_time,payment_date,payment_time,uploaded_at,reviewed_at',
    'id,invoice_id,delivery_id,status,payment_date,payment_time,uploaded_at,reviewed_at',
    'id,invoice_id,delivery_id,status,reported_payment_date,reported_payment_time,uploaded_at,reviewed_at',
    'id,invoice_id,delivery_id,status,uploaded_at,reviewed_at'
  ];
  let rows;
  let loaded = false;
  let lastSchemaError = null;
  for (const fields of selects) {
    try {
      rows = await supabaseFetch(env, `/rest/v1/payment_proofs?select=${fields}${suffix}`);
      loaded = true;
      break;
    } catch (error) {
      if (!isSchemaError(error)) throw error;
      lastSchemaError = error;
    }
  }
  if (!loaded) {
    if (lastSchemaError && isSchemaError(lastSchemaError)) {
      throw new Error('Payment proof table is missing or its required columns are unavailable. Check db-migration-part-12.sql.');
    }
  }
  return (Array.isArray(rows) ? rows : [])
    .filter((proof) => paymentProofBelongsToDeliveryInvoice(proof, delivery, invoice));
}

async function handlePublicPaymentProofsGet(request, env) {
  try {
    const url = new URL(request.url);
    const auth = await authorizePublicPaymentProofRequest(request, env, url.searchParams.get('slug') || '');
    if (auth.error) return auth.error;
    const proofs = await loadPublicPaymentProofRows(env, auth.delivery, auth.invoice);
    return json({
      ok: true,
      ask_open: invoiceHasActivePaymentRequest(auth.invoice),
      proofs: proofs.map((proof) => ({
        ...sanitizePublicPaymentProof(proof),
        current_request: paymentProofIsForCurrentAsk(proof, auth.invoice)
      })),
      locked: invoiceLocksPublicPaymentProofs(auth.invoice) || proofs.some((proof) =>
        paymentProofIsForCurrentAsk(proof, auth.invoice)
        && !CLIENT_DELETABLE_PAYMENT_PROOF_STATUSES.has(publicPaymentProofStatus(proof.status))
      )
    }, 200, { 'Cache-Control': 'private, no-store' });
  } catch (error) {
    return json({ error: error?.message || 'Could not load payment proofs.' }, 500);
  }
}

async function handlePublicPaymentProofImageGet(request, env) {
  try {
    const url = new URL(request.url);
    const id = String(url.searchParams.get('id') || '').trim();
    if (!id) return json({ error: 'Missing payment proof id.' }, 400);
    const auth = await authorizePublicPaymentProofRequest(request, env, url.searchParams.get('slug') || '');
    if (auth.error) return auth.error;

    const rows = await supabaseFetch(
      env,
      `/rest/v1/payment_proofs?select=id,invoice_id,delivery_id,client_id,event_key,event_date,image_path,mime_type,original_filename,status,uploaded_at,reviewed_at&id=eq.${encodeURIComponent(id)}&limit=1`
    );
    const proof = Array.isArray(rows) ? rows[0] : rows;
    if (!proof?.image_path || !paymentProofBelongsToDeliveryInvoice(proof, auth.delivery, auth.invoice)) {
      return json({ error: 'Payment proof not found.' }, 404);
    }

    const stored = await paymentProofStorageRequest(env, proof.image_path, { method: 'GET' });
    return new Response(stored.body, {
      status: 200,
      headers: {
        'Content-Type': proof.mime_type || stored.headers.get('Content-Type') || 'image/jpeg',
        'Content-Disposition': `inline; filename="${String(proof.original_filename || 'payment-proof.jpg').replace(/["\\]/g, '')}"`,
        'Cache-Control': 'private, no-store',
        'X-Content-Type-Options': 'nosniff'
      }
    });
  } catch (error) {
    return json({ error: error?.message || 'Could not load payment proof.' }, 500);
  }
}

async function handlePublicPaymentProofDelete(request, env) {
  const limited = enforceRateLimit(request, 'payment-proof-write', { limit: 10, windowMs: 60 * 1000, blockMs: 5 * 60 * 1000 });
  if (limited) return limited;
  try {
    const body = await request.json().catch(() => ({}));
    const proofId = String(body.proofId || '').trim();
    if (!proofId) return json({ error: 'Missing payment proof id.' }, 400);
    const auth = await authorizePublicPaymentProofRequest(request, env, body.slug || '');
    if (auth.error) return auth.error;
    if (invoiceLocksPublicPaymentProofs(auth.invoice)) {
      return json({ error: 'Confirmed payment proofs are read-only.' }, 409);
    }

    const allProofs = await supabaseFetch(
      env,
      `/rest/v1/payment_proofs?select=*&invoice_id=eq.${encodeURIComponent(auth.invoice.id)}&delivery_id=eq.${encodeURIComponent(auth.delivery.id)}&order=uploaded_at.asc`
    );
    const ownedProofs = (Array.isArray(allProofs) ? allProofs : [])
      .filter((proof) => paymentProofBelongsToDeliveryInvoice(proof, auth.delivery, auth.invoice));
    if (ownedProofs.some((proof) => !CLIENT_DELETABLE_PAYMENT_PROOF_STATUSES.has(publicPaymentProofStatus(proof.status)))) {
      return json({ error: 'Confirmed payment proofs are read-only.' }, 409);
    }

    const proof = ownedProofs.find((row) => String(row.id || '') === proofId);
    if (!proof?.image_path) return json({ error: 'Payment proof not found.' }, 404);
    const status = publicPaymentProofStatus(proof.status);
    if (!CLIENT_DELETABLE_PAYMENT_PROOF_STATUSES.has(status)) {
      return json({ error: 'This payment proof cannot be deleted.' }, 409);
    }

    // Delete the private object first. If the following conditional row
    // deletion fails, surface the failure instead of claiming success.
    await paymentProofStorageRequest(env, proof.image_path, { method: 'DELETE' });
    const deleted = await supabaseFetch(
      env,
      `/rest/v1/payment_proofs?id=eq.${encodeURIComponent(proof.id)}&invoice_id=eq.${encodeURIComponent(auth.invoice.id)}&delivery_id=eq.${encodeURIComponent(auth.delivery.id)}&status=eq.${encodeURIComponent(status)}`,
      { method: 'DELETE', headers: { Prefer: 'return=representation' } }
    );
    if (!Array.isArray(deleted) || deleted.length !== 1) {
      return json({ error: 'The proof image was removed, but its record could not be deleted. Please contact support.' }, 500);
    }
    return json({ ok: true, deletedId: String(proof.id) });
  } catch (error) {
    return json({ error: error?.message || 'Could not delete payment proof.' }, 500);
  }
}

async function handlePaymentProofSubmit(request, env) {
  const limited = enforceRateLimit(request, 'payment-proof-write', { limit: 10, windowMs: 60 * 1000, blockMs: 5 * 60 * 1000 });
  if (limited) return limited;
  const uploadedPaths = [];
  try {
    const body = await request.json().catch(() => ({}));
    const images = cleanPublicProofImages(body.images);
    const paymentDateRaw = String(body.paymentDate || body.payment_date || '').trim();
    const paymentTimeRaw = String(body.paymentTime || body.payment_time || '').trim();
    const paymentDate = cleanPaymentProofDate(paymentDateRaw);
    const paymentTime = cleanPaymentProofTime(paymentTimeRaw);
    const timezoneOffset = cleanPaymentProofTimezoneOffset(
      body.paymentTimezoneOffsetMinutes ?? body.payment_timezone_offset_minutes
    );
    if (paymentDateRaw && !paymentDate) return json({ error: 'Payment date is invalid.' }, 400);
    if (paymentTimeRaw && !paymentTime) return json({ error: 'Payment time is invalid.' }, 400);
    if (paymentTime && !paymentDate) return json({ error: 'Payment date is required when payment time is provided.' }, 400);
    if ((body.paymentTimezoneOffsetMinutes ?? body.payment_timezone_offset_minutes) != null && timezoneOffset == null) {
      return json({ error: 'Payment timezone offset is invalid.' }, 400);
    }
    const auth = await authorizePublicPaymentProofRequest(request, env, body.slug || body.shortCode || '');
    if (auth.error) return auth.error;
    const { delivery, invoice } = auth;
    if (!invoiceHasActivePaymentRequest(invoice)) {
      return json({ error: 'There is no active payment request.' }, 409);
    }
    const existingProofs = await loadPublicPaymentProofRows(env, delivery, invoice);
    if (invoiceLocksPublicPaymentProofs(invoice)) {
      return json({ error: 'Payment is already confirmed.' }, 409);
    }
    const currentAskProofs = existingProofs.filter((proof) => paymentProofIsForCurrentAsk(proof, invoice));
    if (currentAskProofs.some((proof) => publicPaymentProofStatus(proof.status) === 'pending')) {
      return json({ error: 'A payment proof is already pending review.' }, 409);
    }
    if (currentAskProofs.some((proof) => !CLIENT_DELETABLE_PAYMENT_PROOF_STATUSES.has(publicPaymentProofStatus(proof.status)))) {
      return json({ error: 'Payment proof has already been processed and is read-only.' }, 409);
    }

    const uploadedAt = new Date().toISOString();
    const proofRows = [];
    for (let index = 0; index < images.length; index += 1) {
      const parsed = parsePaymentProofDataUrl(images[index]);
      const proofId = crypto.randomUUID();
      const imagePath = `${invoice.id}/${proofId}.${parsed.extension}`;
      await paymentProofStorageRequest(env, imagePath, {
        method: 'POST',
        headers: {
          'Content-Type': parsed.mimeType,
          'x-upsert': 'false'
        },
        body: parsed.bytes
      });
      uploadedPaths.push(imagePath);
      proofRows.push({
        id: proofId,
        invoice_id: invoice.id,
        delivery_id: delivery.id,
        client_id: invoice.client_id || delivery.client_id || null,
        event_key: invoice.event_key || delivery.event_key || '',
        event_date: invoice.event_date || delivery.event_date || '',
        image_path: imagePath,
        original_filename: `payment-proof-${index + 1}.${parsed.extension}`,
        mime_type: parsed.mimeType,
        status: 'pending',
        reported_payment_date: paymentDate || null,
        reported_payment_time: paymentDate && paymentTime ? paymentTime : null,
        reported_timezone_offset_minutes: paymentDate ? timezoneOffset : null,
        payment_date: paymentDate || null,
        payment_time: paymentDate && paymentTime ? paymentTime : null,
        uploaded_at: uploadedAt
      });
    }

    let saved;
    // Retry schema mismatches in descending order of information preserved.
    // A missing optional timestamp column must not erase every other timestamp.
    const insertVariants = [
      [],
      ['reported_timezone_offset_minutes'],
      ['reported_timezone_offset_minutes', 'reported_payment_date', 'reported_payment_time'],
      ['reported_timezone_offset_minutes', 'payment_date', 'payment_time']
    ];
    let lastSchemaError = null;
    let inserted = false;
    for (const omittedFields of insertVariants) {
      const payload = omittedFields.length
        ? proofRows.map((proof) => Object.fromEntries(
          Object.entries(proof).filter(([key]) => !omittedFields.includes(key))
        ))
        : proofRows;
      try {
        saved = await supabaseFetch(env, '/rest/v1/payment_proofs', {
          method: 'POST',
          headers: { Prefer: 'return=representation' },
          body: JSON.stringify(payload)
        });
        inserted = true;
        break;
      } catch (error) {
        if (!isSchemaError(error)) throw error;
        lastSchemaError = error;
      }
    }
    if (!inserted) throw lastSchemaError || new Error('Could not save payment proof.');
    const safeSaved = (Array.isArray(saved) ? saved : [saved].filter(Boolean))
      .filter((proof) => paymentProofBelongsToDeliveryInvoice(proof, delivery, invoice))
      .map(sanitizePublicPaymentProof);
    return json({ ok: true, proofs: safeSaved });
  } catch (error) {
    await Promise.allSettled(uploadedPaths.map((path) => paymentProofStorageRequest(env, path, { method: 'DELETE' })));
    const status = Number(error?.status) || 500;
    return json({ error: error?.message || 'Could not upload payment proof.' }, status);
  }
}

async function handlePaymentProofReview(request, env) {
  const body = await request.json().catch(() => ({}));
  const password = String(body.password || '').trim();
  if (!(await verifyAdminRequest(request, env, password))) return json({ error: 'Unauthorized.' }, 401, {}, request);

  const invoiceId = String(body.invoiceId || body.invoice_id || '').trim();
  const proofId = String(body.proofId || body.proof_id || '').trim();
  const rawProofIds = Array.isArray(body.proofIds) ? body.proofIds : (proofId ? [proofId] : []);
  const requestedProofIds = [...new Set(rawProofIds.map((id) => String(id || '').trim()).filter(Boolean))];
  const action = String(body.action || '').trim().toLowerCase();
  if (!invoiceId) return json({ error: 'Missing invoice id.' }, 400, {}, request);
  if (!['confirm', 'reject', 'reopen_request'].includes(action)) {
    return json({ error: 'Invalid review action.' }, 400, {}, request);
  }

  const invRows = await supabaseFetch(
    env,
    `/rest/v1/invoices?select=*&id=eq.${encodeURIComponent(invoiceId)}&limit=1`
  );
  const invoice = Array.isArray(invRows) ? invRows[0] : invRows;
  if (!invoice?.id) return json({ error: 'Invoice not found.' }, 404, {}, request);

  const existingData = (invoice.invoice_data && typeof invoice.invoice_data === 'object')
    ? { ...invoice.invoice_data }
    : {};
  const grandTotal = Math.max(
    0,
    Math.round(Number(invoice.grand_total || invoice.total || invoice.price) || 0)
  );
  const expectedUpdatedAt = String(invoice.updated_at || '').trim();
  const invoiceOptimisticPath = expectedUpdatedAt
    ? `/rest/v1/invoices?id=eq.${encodeURIComponent(invoiceId)}&updated_at=eq.${encodeURIComponent(expectedUpdatedAt)}`
    : `/rest/v1/invoices?id=eq.${encodeURIComponent(invoiceId)}`;

  if (action === 'reopen_request') {
    const nextData = {
      ...existingData,
      depositAskOpen: true,
      depositAskOpenedAt: new Date().toISOString(),
    };
    const nextStatus = String(invoice.status || '').toLowerCase() === 'paid' ? 'deposit' : (invoice.status || 'deposit');
    const patchedInvRows = await supabaseFetch(
      env,
      invoiceOptimisticPath,
      {
        method: 'PATCH',
        headers: { Prefer: 'return=representation' },
        body: JSON.stringify({
          status: nextStatus,
          invoice_data: nextData,
        }),
      }
    );
    const updatedList = Array.isArray(patchedInvRows) ? patchedInvRows : [patchedInvRows].filter(Boolean);
    if (!updatedList.length && expectedUpdatedAt) {
      return json({ error: 'Invoice was updated by another request. Please refresh and try again.' }, 409, {}, request);
    }
    return json({ ok: true, invoice: updatedList[0] || { ...invoice, status: nextStatus, invoice_data: nextData } }, 200, {}, request);
  }

  const primaryProofId = proofId || requestedProofIds[0] || '';
  if (!primaryProofId) return json({ error: 'Missing payment proof id.' }, 400, {}, request);

  const allInvoiceProofs = await supabaseFetch(
    env,
    `/rest/v1/payment_proofs?select=*&invoice_id=eq.${encodeURIComponent(invoiceId)}&order=uploaded_at.asc`
  ).then((rows) => (Array.isArray(rows) ? rows : []));

  const proof = allInvoiceProofs.find((p) => String(p?.id || '') === primaryProofId);
  if (!proof?.id) return json({ error: 'Payment proof not found.' }, 404, {}, request);

  const targetUploadedAt = String(proof.uploaded_at || '').trim();
  const batchProofs = allInvoiceProofs.filter((p) => {
    const pid = String(p?.id || '');
    if (!pid) return false;
    if (requestedProofIds.includes(pid)) return true;
    if (targetUploadedAt && String(p?.uploaded_at || '').trim() === targetUploadedAt) return true;
    return false;
  });
  const batchProofIds = batchProofs.map((p) => String(p.id));
  const batchFilter = `invoice_id=eq.${encodeURIComponent(invoiceId)}&id=in.(${inFilter(batchProofIds)})`;

  const reviewedAt = new Date().toISOString();

  if (action === 'reject') {
    let updatedInvoice = invoice;
    if (String(invoice.status || '').toLowerCase() === 'deposit' && existingData.depositAskOpen === false) {
      const nextData = { ...existingData, depositAskOpen: true };
      const iRows = await supabaseFetch(
        env,
        invoiceOptimisticPath,
        {
          method: 'PATCH',
          headers: { Prefer: 'return=representation' },
          body: JSON.stringify({ invoice_data: nextData }),
        }
      );
      const updatedList = Array.isArray(iRows) ? iRows : [iRows].filter(Boolean);
      if (!updatedList.length && expectedUpdatedAt) {
        return json({ error: 'Invoice was updated by another request. Please refresh and try again.' }, 409, {}, request);
      }
      updatedInvoice = updatedList[0] || { ...invoice, invoice_data: nextData };
    }

    let patchedProofs = [];
    try {
      const pRows = await supabaseFetch(
        env,
        `/rest/v1/payment_proofs?${batchFilter}`,
        {
          method: 'PATCH',
          headers: { Prefer: 'return=representation' },
          body: JSON.stringify({ status: 'rejected', reviewed_at: reviewedAt }),
        }
      );
      patchedProofs = Array.isArray(pRows) ? pRows : [pRows].filter(Boolean);
    } catch (error) {
      if (!isSchemaError(error)) throw error;
    }

    const fallbackProofs = batchProofs.map((p) => ({ ...p, status: 'rejected', reviewed_at: reviewedAt }));
    return json({
      ok: true,
      invoice: updatedInvoice,
      proof: patchedProofs[0] || fallbackProofs[0],
      proofs: patchedProofs.length ? patchedProofs : fallbackProofs,
    }, 200, {}, request);
  }

  // action === 'confirm' — strict server-side accounting validation
  const amount = Math.max(0, Math.round(Number(body.amount) || 0));
  if (amount <= 0) return json({ error: 'Transfer amount must be greater than zero.' }, 400, {}, request);

  const wibNow = new Date(Date.now() + 7 * 60 * 60 * 1000);
  const fallbackDate = wibNow.toISOString().slice(0, 10);
  const fallbackTime = wibNow.toISOString().slice(11, 16);
  const paymentDate = cleanPaymentProofDate(body.paymentDate || proof.payment_date || proof.reported_payment_date) || fallbackDate;
  const paymentTime = cleanPaymentProofTime(body.paymentTime || proof.payment_time || proof.reported_payment_time) || fallbackTime;

  let depositPayments = Array.isArray(existingData.depositPayments)
    ? existingData.depositPayments.map((item) => ({ ...item }))
    : [];

  if (
    !depositPayments.length
    && String(invoice.status || '').toLowerCase() === 'deposit'
    && Math.round(Number(invoice.paid_amount) || 0) > 0
  ) {
    depositPayments.push({
      id: crypto.randomUUID(),
      paid: true,
      paidAtDate: cleanPaymentProofDate(invoice.invoice_date) || fallbackDate,
      paidAtTime: '',
      amount: Math.max(0, Math.round(Number(invoice.paid_amount) || 0)),
    });
  }

  const existingLinkedId = batchProofs
    .map((p) => String(p?.linked_payment_id || '').trim())
    .find(Boolean) || '';

  const paidDepositsBefore = depositPayments
    .filter((p) => p?.paid && (!existingLinkedId || String(p.id || '') !== existingLinkedId))
    .reduce((sum, p) => sum + Math.max(0, Math.round(Number(p.amount) || 0)), 0);

  const remainingBalance = grandTotal > 0 ? Math.max(0, grandTotal - paidDepositsBefore) : 0;

  if (grandTotal > 0 && amount > remainingBalance) {
    return json({
      error: `Transfer amount (${amount}) exceeds the remaining balance due (${remainingBalance}). Please verify the amount.`,
    }, 400, {}, request);
  }

  const requestedMode = String(body.mode || '').trim().toLowerCase();
  if (requestedMode === 'paid' && grandTotal > 0 && (paidDepositsBefore + amount < grandTotal)) {
    return json({
      error: `Cannot mark Full Paid: transfer amount (${amount}) is less than the remaining balance due (${remainingBalance}).`,
    }, 400, {}, request);
  }

  const isFullSettlement = grandTotal > 0
    ? (paidDepositsBefore + amount === grandTotal)
    : (requestedMode === 'paid');

  let nextStatus = 'deposit';
  let nextPaidAmount = 0;
  let nextBalanceDue = 0;
  let linkedPaymentId = existingLinkedId || '';
  const nextData = { ...existingData };

  if (isFullSettlement) {
    nextStatus = 'paid';
    if (existingLinkedId && existingLinkedId !== 'paid-receipt') {
      depositPayments = depositPayments.filter((p) => String(p?.id || '') !== existingLinkedId);
    }
    nextData.depositPayments = depositPayments;
    nextData.depositAskOpen = false;
    nextData.paidReceipt = {
      paid: true,
      paidAtDate: paymentDate,
      paidAtTime: paymentTime,
      amount: grandTotal || (paidDepositsBefore + amount),
    };
    nextPaidAmount = grandTotal || (paidDepositsBefore + amount);
    nextBalanceDue = 0;
    linkedPaymentId = 'paid-receipt';
  } else {
    nextStatus = 'deposit';
    if (existingLinkedId && existingLinkedId !== 'paid-receipt' && depositPayments.some((p) => String(p?.id || '') === existingLinkedId)) {
      depositPayments = depositPayments.map((p) =>
        String(p?.id || '') === existingLinkedId
          ? { ...p, paid: true, paidAtDate: paymentDate, paidAtTime: paymentTime, amount }
          : p
      );
    } else {
      linkedPaymentId = crypto.randomUUID();
      depositPayments.push({
        id: linkedPaymentId,
        paid: true,
        paidAtDate: paymentDate,
        paidAtTime: paymentTime,
        amount,
      });
    }
    nextData.depositPayments = depositPayments;
    nextData.depositAskOpen = false;
    nextData.requestBalanceDue = true;
    nextPaidAmount = depositPayments
      .filter((p) => p?.paid)
      .reduce((sum, p) => sum + Math.max(0, Math.round(Number(p.amount) || 0)), 0);
    nextBalanceDue = Math.max(0, grandTotal - nextPaidAmount);
  }

  // Step 1: Update the invoice FIRST with optimistic concurrency lock (updated_at).
  // If another concurrent request already modified the invoice, abort with 409 Conflict
  // before touching payment_proofs.
  const patchedInvRows = await supabaseFetch(
    env,
    invoiceOptimisticPath,
    {
      method: 'PATCH',
      headers: { Prefer: 'return=representation' },
      body: JSON.stringify({
        status: nextStatus,
        paid_amount: nextPaidAmount,
        balance_due: nextBalanceDue,
        invoice_data: nextData,
      }),
    }
  );
  const updatedInvList = Array.isArray(patchedInvRows) ? patchedInvRows : [patchedInvRows].filter(Boolean);
  if (!updatedInvList.length && expectedUpdatedAt) {
    return json({ error: 'Invoice was modified by another request. Please refresh and try again.' }, 409, {}, request);
  }
  const updatedInvoice = updatedInvList[0] || {
    ...invoice,
    status: nextStatus,
    paid_amount: nextPaidAmount,
    balance_due: nextBalanceDue,
    invoice_data: nextData,
  };

  // Step 2: Update the payment_proofs batch. If this fails for a non-schema reason,
  // compensate by restoring the invoice to its previous snapshot so both tables stay in sync.
  const richProofPatch = {
    status: 'confirmed',
    reviewed_at: reviewedAt,
    payment_date: paymentDate,
    payment_time: paymentTime || null,
    linked_payment_id: linkedPaymentId || null,
  };
  let patchedProofs = [];
  try {
    try {
      const pRows = await supabaseFetch(
        env,
        `/rest/v1/payment_proofs?${batchFilter}`,
        {
          method: 'PATCH',
          headers: { Prefer: 'return=representation' },
          body: JSON.stringify(richProofPatch),
        }
      );
      patchedProofs = Array.isArray(pRows) ? pRows : [pRows].filter(Boolean);
    } catch (error) {
      if (!isSchemaError(error)) throw error;
      const pRows = await supabaseFetch(
        env,
        `/rest/v1/payment_proofs?${batchFilter}`,
        {
          method: 'PATCH',
          headers: { Prefer: 'return=representation' },
          body: JSON.stringify({ status: 'confirmed', reviewed_at: reviewedAt }),
        }
      );
      patchedProofs = Array.isArray(pRows) ? pRows : [pRows].filter(Boolean);
    }
  } catch (proofError) {
    await supabaseFetch(env, `/rest/v1/invoices?id=eq.${encodeURIComponent(invoiceId)}`, {
      method: 'PATCH',
      headers: { Prefer: 'return=minimal' },
      body: JSON.stringify({
        status: invoice.status,
        paid_amount: invoice.paid_amount,
        balance_due: invoice.balance_due,
        invoice_data: existingData,
      }),
    }).catch(() => {});
    throw proofError;
  }

  const fallbackProofs = batchProofs.map((p) => ({ ...p, ...richProofPatch }));
  return json({
    ok: true,
    invoice: updatedInvoice,
    proof: patchedProofs[0] || fallbackProofs[0],
    proofs: patchedProofs.length ? patchedProofs : fallbackProofs,
  }, 200, {}, request);
}

async function handlePaymentProofImageGet(request, env) {
  const url = new URL(request.url);
  const password = String(url.searchParams.get('password') || '').trim();
  if (!(await verifyAdminRequest(request, env, password))) return json({ error: 'Unauthorized.' }, 401);
  const id = String(url.searchParams.get('id') || '').trim();
  if (!id) return json({ error: 'Missing payment proof id.' }, 400);

  const rows = await supabaseFetch(
    env,
    `/rest/v1/payment_proofs?select=id,image_path,mime_type,original_filename&id=eq.${encodeURIComponent(id)}&limit=1`
  );
  const proof = Array.isArray(rows) ? rows[0] : rows;
  if (!proof?.image_path) return json({ error: 'Payment proof not found.' }, 404);

  const stored = await paymentProofStorageRequest(env, proof.image_path, { method: 'GET' });
  return new Response(stored.body, {
    status: 200,
    headers: {
      'Content-Type': proof.mime_type || stored.headers.get('Content-Type') || 'image/jpeg',
      'Content-Disposition': `inline; filename="${String(proof.original_filename || 'payment-proof.jpg').replace(/[\"\\]/g, '')}"`,
      'Cache-Control': 'private, no-store',
      'X-Content-Type-Options': 'nosniff',
      'Content-Security-Policy': "default-src 'none'"
    }
  });
}

async function handleInvoiceDelete(request, env) {
  const body = await request.json();
  const password = String(body.password || '').trim();
  const id = String(body.id || '').trim();
  if (!(await verifyAdminRequest(request, env, password))) return json({ error: 'Unauthorized.' }, 401);
  if (!id) return json({ error: 'Missing invoice id.' }, 400);

  const proofs = await supabaseFetch(
    env,
    `/rest/v1/payment_proofs?select=image_path&invoice_id=eq.${encodeURIComponent(id)}`
  ).catch((error) => isSchemaError(error) ? [] : Promise.reject(error));
  await Promise.allSettled((Array.isArray(proofs) ? proofs : [])
    .map((proof) => String(proof?.image_path || '').trim())
    .filter(Boolean)
    .map((path) => paymentProofStorageRequest(env, path, { method: 'DELETE' })));

  await supabaseFetch(env, `/rest/v1/invoices?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: { Prefer: 'return=minimal' }
  });
  return json({ ok: true });
}

// ── Invoice packages (item catalogue) ──────────────────────────────
// Powers the /inv autocomplete: 5 hardcoded defaults plus any custom
// packages saved from the invoice generator. Schema lives in
// db-migration-part-5.sql.

const DEFAULT_INVOICE_PACKAGES = [
  { id: 'school-basic',         name: 'School without Magician', price: 800000,  note: 'school celebration without magician',           is_default: true },
  { id: 'school-magician',      name: 'School with Magician',    price: 1000000, note: 'school celebration with magician',              is_default: true },
  { id: 'studio-special',       name: 'Studio Special',          price: 800000,  note: 'up to 1 hour',                                  is_default: true },
  { id: 'intimate-party',       name: 'Intimate Party',          price: 1300000, note: 'up to 2 hours, suitable for family celebration', is_default: true },
  { id: 'birthday-celebration', name: 'Birthday Celebration',    price: 1650000, note: 'up to 3.5 hours, suitable for Birthday Celebration', is_default: true }
];

function normalizeInvoicePackagePayload(raw = {}) {
  const cleanInt = (v, fallback = 0) => {
    const n = Math.round(Number(v));
    return Number.isFinite(n) && n >= 0 ? n : fallback;
  };
  return {
    name: String(raw.name || '').trim().slice(0, 160),
    price: cleanInt(raw.price, 0),
    note: String(raw.note || '').trim().slice(0, 400)
  };
}

async function handlePackagesGet(request, env) {
  if (!(await verifyAdminRequest(request, env))) return json({ error: 'Unauthorized.' }, 401);
  try {
    const rows = await supabaseFetch(
      env,
      '/rest/v1/invoice_packages?select=*&order=is_default.desc,name.asc'
    );
    const packages = Array.isArray(rows) ? rows : [];
    return json({ ok: true, packages });
  } catch (error) {
    // Keep the hardcoded defaults available when the optional package
    // catalogue table has not been created yet.
    if (isSchemaError(error)) {
      return json({ ok: true, packages: DEFAULT_INVOICE_PACKAGES, fallback: true });
    }
    throw error;
  }
}

async function handlePackageSave(request, env) {
  const body = await request.json().catch(() => ({}));
  const password = String(body.password || '').trim();
  if (!(await verifyAdminRequest(request, env, password))) return json({ error: 'Unauthorized.' }, 401);

  const incoming = body.package || body;
  const payload = normalizeInvoicePackagePayload(incoming);
  if (!payload.name) return json({ error: 'Package name is required.' }, 400);
  if (!payload.price) return json({ error: 'Package price is required.' }, 400);

  const id = String(incoming.id || '').trim();

  // If the row exists and is flagged as default, preserve that flag on update
  // so we never accidentally lose a default's protection.
  let existing = null;
  if (id) {
    existing = await supabaseFetch(
      env,
      `/rest/v1/invoice_packages?select=*&id=eq.${encodeURIComponent(id)}&limit=1`
    )
      .then((rows) => Array.isArray(rows) ? rows[0] : rows)
      .catch(() => null);
  }

  if (id && existing) {
    const rows = await supabaseFetch(
      env,
      `/rest/v1/invoice_packages?id=eq.${encodeURIComponent(id)}`,
      {
        method: 'PATCH',
        headers: { Prefer: 'return=representation' },
        body: JSON.stringify(payload)
      }
    );
    const saved = Array.isArray(rows) ? rows[0] : rows;
    return json({ ok: true, package: saved });
  }

  const rows = await supabaseFetch(env, '/rest/v1/invoice_packages', {
    method: 'POST',
    headers: { Prefer: 'return=representation' },
    body: JSON.stringify({ ...payload, is_default: false })
  });
  const saved = Array.isArray(rows) ? rows[0] : rows;
  return json({ ok: true, package: saved });
}

async function handlePackageDelete(request, env) {
  const body = await request.json().catch(() => ({}));
  const password = String(body.password || '').trim();
  const id = String(body.id || '').trim();
  if (!(await verifyAdminRequest(request, env, password))) return json({ error: 'Unauthorized.' }, 401);
  if (!id) return json({ error: 'Missing package id.' }, 400);

  const existing = await supabaseFetch(
    env,
    `/rest/v1/invoice_packages?select=id,is_default&id=eq.${encodeURIComponent(id)}&limit=1`
  )
    .then((rows) => Array.isArray(rows) ? rows[0] : rows)
    .catch(() => null);

  if (!existing) return json({ error: 'Package not found.' }, 404);

  await supabaseFetch(env, `/rest/v1/invoice_packages?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: { Prefer: 'return=minimal' }
  });
  return json({ ok: true });
}

function rootHomepage() {
  return `<!DOCTYPE html>
<html class="ss-force-motion" lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
  <meta name="robots" content="noindex,nofollow">
  <title>StarShots</title>
  <style>${shellStyles()}
    .home-card{width:min(100%,720px);text-align:center;padding:42px 34px;opacity:0;-webkit-transform:translateY(-8px) scale(.992);transform:translateY(-8px) scale(.992);-webkit-transition:opacity 900ms cubic-bezier(.16,1,.3,1),-webkit-transform 900ms cubic-bezier(.16,1,.3,1);transition:opacity 900ms cubic-bezier(.16,1,.3,1),transform 900ms cubic-bezier(.16,1,.3,1)}
    .home-card.is-visible{opacity:1;-webkit-transform:translateY(-20px) scale(1);transform:translateY(-20px) scale(1)}
    .reveal{opacity:0;-webkit-transform:translateY(-10px);transform:translateY(-10px);-webkit-transition:opacity 820ms cubic-bezier(.16,1,.3,1),-webkit-transform 820ms cubic-bezier(.16,1,.3,1);transition:opacity 820ms cubic-bezier(.16,1,.3,1),transform 820ms cubic-bezier(.16,1,.3,1)}
    .reveal.is-visible{opacity:1;-webkit-transform:translateY(0);transform:translateY(0)}
    .stagger-1{-webkit-transition-delay:120ms;transition-delay:120ms}.stagger-2{-webkit-transition-delay:240ms;transition-delay:240ms}.stagger-3{-webkit-transition-delay:360ms;transition-delay:360ms}.stagger-4{-webkit-transition-delay:480ms;transition-delay:480ms}.stagger-5{-webkit-transition-delay:600ms;transition-delay:600ms}.stagger-6{-webkit-transition-delay:720ms;transition-delay:720ms}
    .construct{width:min(260px,58vw);margin:6px auto 22px;display:block;color:var(--accent)}
    .status-pill{display:inline-flex;align-items:center;gap:8px;margin:4px auto 18px;padding:8px 13px;border:1px solid var(--line);border-radius:999px;background:rgba(255,255,255,.42);color:var(--soft);font-size:12px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}
    .ig-link{display:inline-flex;align-items:center;gap:10px;margin-top:24px;color:var(--ink);text-decoration:none;font-size:18px;font-weight:850}
    .ig-link svg{width:28px;height:28px;display:block}
    .ig-link:hover{opacity:.72}
    .ig-link:active{transform:scale(.985)}
    .intro-settled .reveal{transition-delay:0ms!important}
    @media(prefers-color-scheme:dark){.ss-logo-hero{filter:brightness(0) invert(1) sepia(.08) saturate(.7);opacity:.92}}
    @media(prefers-reduced-motion:reduce){html:not(.ss-force-motion) *{-webkit-animation:none!important;animation:none!important;-webkit-transition:none!important;transition:none!important;scroll-behavior:auto!important}html:not(.ss-force-motion) .home-card,html:not(.ss-force-motion) .reveal{opacity:1!important;-webkit-transform:none!important;transform:none!important}}
    @media(max-width:520px){.home-card{padding:32px 22px}.construct{width:min(220px,70vw)}.ig-link{font-size:17px}}
  </style>
  ${animateAssets()}
</head>
<body>
  <div class="wrap center">
    <main class="card home-card">
      <a class="reveal stagger-1" href="/" aria-label="StarShots homepage" style="display:inline-block;text-decoration:none"><img class="ss-logo-hero" src="${LOGO_PATH}" alt="StarShots logo"></a>
      <svg class="construct reveal stagger-2" viewBox="0 0 320 180" aria-hidden="true">
        <g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="8" opacity=".9">
          <path d="M56 142h208"/>
          <path d="M92 142l44-76h48l44 76"/>
          <path d="M118 112h84"/>
          <path d="M136 66l-18-28h84l-18 28"/>
          <path d="M160 66v76"/>
          <path d="M70 142l-22 26M250 142l22 26"/>
        </g>
        <g fill="currentColor" opacity=".18">
          <circle cx="54" cy="44" r="20"/><circle cx="268" cy="58" r="14"/><circle cx="242" cy="28" r="7"/>
        </g>
      </svg>
      <div class="status-pill reveal stagger-3">Private System</div>
      <h1 class="reveal stagger-4">We Are Refining This Space</h1>
      <p class="hero-copy reveal stagger-5">StarShots private delivery is being carefully polished for a cleaner, smoother client experience.</p>
      <a class="ig-link reveal stagger-6" href="https://instagram.com/starshots.id" target="_blank" rel="noopener" aria-label="Open StarShots Instagram">
        <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="4" stroke="currentColor" stroke-width="2"/><circle cx="17.5" cy="6.5" r="1.3" fill="currentColor"/></svg>
        <span>@starshots.id</span>
      </a>
    </main>
  </div>
  <script>
    (function(){
      var card=document.querySelector('.home-card');
      var reduceMotion=window.matchMedia('(prefers-reduced-motion: reduce)').matches && !document.documentElement.classList.contains('ss-force-motion');
      function show(){
        if(card) card.classList.add('is-visible');
        document.querySelectorAll('.reveal').forEach(function(el){el.classList.add('is-visible');});
        setTimeout(function(){document.body.classList.add('intro-settled');}, reduceMotion?0:1500);
      }
      requestAnimationFrame(function(){
        // Two rAFs so the first paint locks in the pre-mount state on iOS.
        requestAnimationFrame(show);
      });
      // Safety: even if rAF chain breaks, force-show after 1500ms.
      setTimeout(show, 1500);
    })();
  </script>
</body>
</html>`;
}

/**
 * Friendly "page not found" page for unknown URLs.
 *
 * Why this exists in this exact shape:
 *   - The previous build sent every unknown URL to "/" with a 302
 *     redirect. That kept the address bar showing whatever the user
 *     mistyped (`/in`, `/xx`, `/inva`...) which was confusing — the
 *     URL didn't match the page they ended up on.
 *   - We now serve a real 404 so the URL stays as-is and the browser
 *     marks it as an error response. That also tightens the rate
 *     limit story: scanners crawling the URL space hit a 404 wall
 *     plus a 3/min cap (see assetOrFallback), without us also having
 *     to rewrite the URL.
 *   - Visual identity matches the homepage card (same background,
 *     same logo, same hero spacing) so users land on something that
 *     still feels like StarShots.
 *   - Reserved paths (/inv, /l, /admin, /db, /g/<slug>, /<short>) are
 *     handled by their own routes earlier in fetch(); they never
 *     reach this 404 unless the underlying record is missing.
 */
function notFoundPage(path = '') {
  const safePath = escapeHtml(path || '/');
  return `<!DOCTYPE html>
<html class="ss-force-motion" lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
  <meta name="robots" content="noindex,nofollow">
  <title>StarShots · Not Found</title>
  <style>${shellStyles()}
    .home-card{width:min(100%,640px);text-align:center;padding:42px 34px;opacity:0;-webkit-transform:translateY(-8px) scale(.992);transform:translateY(-8px) scale(.992);-webkit-transition:opacity 900ms cubic-bezier(.16,1,.3,1),-webkit-transform 900ms cubic-bezier(.16,1,.3,1);transition:opacity 900ms cubic-bezier(.16,1,.3,1),transform 900ms cubic-bezier(.16,1,.3,1)}
    .home-card.is-visible{opacity:1;-webkit-transform:translateY(-20px) scale(1);transform:translateY(-20px) scale(1)}
    .reveal{opacity:0;-webkit-transform:translateY(-10px);transform:translateY(-10px);-webkit-transition:opacity 820ms cubic-bezier(.16,1,.3,1),-webkit-transform 820ms cubic-bezier(.16,1,.3,1);transition:opacity 820ms cubic-bezier(.16,1,.3,1),transform 820ms cubic-bezier(.16,1,.3,1)}
    .reveal.is-visible{opacity:1;-webkit-transform:translateY(0);transform:translateY(0)}
    .stagger-1{-webkit-transition-delay:120ms;transition-delay:120ms}.stagger-2{-webkit-transition-delay:240ms;transition-delay:240ms}.stagger-3{-webkit-transition-delay:360ms;transition-delay:360ms}.stagger-4{-webkit-transition-delay:480ms;transition-delay:480ms}.stagger-5{-webkit-transition-delay:600ms;transition-delay:600ms}.stagger-6{-webkit-transition-delay:720ms;transition-delay:720ms}
    .nf-code{font-family:"Cormorant Garamond","Times New Roman",serif;font-size:clamp(72px,18vw,128px);font-weight:300;line-height:.95;letter-spacing:-.04em;color:var(--ink);margin:0 0 4px}
    .status-pill{display:inline-flex;align-items:center;gap:8px;margin:6px auto 18px;padding:8px 13px;border:1px solid var(--line);border-radius:999px;background:rgba(255,255,255,.42);color:var(--soft);font-size:12px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}
    .nf-path{display:inline-block;margin-top:14px;padding:6px 12px;border:1px solid var(--line);border-radius:999px;background:var(--solid);color:var(--soft);font-size:12px;font-weight:800;letter-spacing:.06em;font-family:ui-monospace,Menlo,Consolas,monospace;max-width:90%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;vertical-align:middle}
    .nf-actions{display:flex;flex-wrap:wrap;gap:12px;justify-content:center;margin-top:26px}
    .nf-btn{display:inline-flex;align-items:center;gap:8px;padding:13px 22px;border-radius:14px;border:1px solid var(--line);background:var(--solid);color:var(--ink);text-decoration:none;font-size:14px;font-weight:800;letter-spacing:.02em;transition:transform .25s cubic-bezier(.22,1,.36,1),box-shadow .25s cubic-bezier(.22,1,.36,1),background .25s cubic-bezier(.22,1,.36,1)}
    .nf-btn.primary{background:var(--ink);color:var(--card);border-color:transparent;box-shadow:0 14px 30px -12px rgba(26,26,26,.45),0 4px 10px -4px rgba(26,26,26,.28)}
    .nf-btn:hover{transform:translateY(-2px)}
    .nf-btn:active{transform:translateY(0) scale(.992)}
    .intro-settled .reveal{transition-delay:0ms!important}
    @media(prefers-color-scheme:dark){.ss-logo-hero{filter:brightness(0) invert(1) sepia(.08) saturate(.7);opacity:.92}}
    @media(prefers-reduced-motion:reduce){html:not(.ss-force-motion) *{-webkit-animation:none!important;animation:none!important;-webkit-transition:none!important;transition:none!important;scroll-behavior:auto!important}html:not(.ss-force-motion) .home-card,html:not(.ss-force-motion) .reveal{opacity:1!important;-webkit-transform:none!important;transform:none!important}}
    @media(max-width:520px){.home-card{padding:32px 22px}.nf-actions{flex-direction:column}.nf-btn{width:100%;justify-content:center}}
  </style>
  ${animateAssets()}
</head>
<body>
  <div class="wrap center">
    <main class="card home-card" role="main">
      <a class="reveal stagger-1" href="/" aria-label="StarShots homepage" style="display:inline-block;text-decoration:none"><img class="ss-logo-hero" src="${LOGO_PATH}" alt="StarShots logo"></a>
      <p class="nf-code reveal stagger-2">404</p>
      <div class="status-pill reveal stagger-3">Page Not Found</div>
      <h1 class="reveal stagger-4">This Page Doesn't Exist</h1>
      <p class="hero-copy reveal stagger-5">The address you tried isn't part of StarShots. Double-check the link or head back to the homepage.</p>
      <p class="reveal stagger-5"><span class="nf-path">${safePath}</span></p>
      <div class="nf-actions reveal stagger-6">
        <a class="nf-btn primary" href="/">Go to Homepage</a>
        <a class="nf-btn" href="https://instagram.com/starshots.id" target="_blank" rel="noopener">@starshots.id</a>
      </div>
    </main>
  </div>
  <script>
    (function(){
      var card=document.querySelector('.home-card');
      var reduceMotion=window.matchMedia('(prefers-reduced-motion: reduce)').matches && !document.documentElement.classList.contains('ss-force-motion');
      function show(){
        if(card) card.classList.add('is-visible');
        document.querySelectorAll('.reveal').forEach(function(el){el.classList.add('is-visible');});
        setTimeout(function(){document.body.classList.add('intro-settled');}, reduceMotion?0:1500);
      }
      requestAnimationFrame(function(){requestAnimationFrame(show);});
      setTimeout(show, 1500);
    })();
  </script>
</body>
</html>`;
}

/**
 * Wrap the entry-HTML responses we serve from the Pages asset
 * bundle (and the inline rootHomepage / notFoundPage strings) with
 * cache headers that force the browser to revalidate every time.
 *
 * Background. The hashed JS/CSS bundles emitted by Vite are
 * content-addressed and can be cached forever — that part is fine.
 * The entry HTML (g/index.html, db/index.html, …) is the index
 * that pins which hashed bundle gets loaded; if a mobile browser
 * keeps a stale entry HTML it will render an old build forever.
 *
 * That is the exact failure mode behind the "Android still shows
 * the old `Hello, Title Name` UI after clearing site data" report
 * for /g/<slug> and /<short>: those routes are served by the same
 * /g/index.html as desktop (this worker rewrites both to /g/), but
 * Pages' default ETag-based revalidation is treated as
 * opportunistic by several Android engines (Firefox Focus and the
 * DuckDuckGo browser in particular), so the old entry sticks
 * around and pulls in stale CSS/JS.
 *
 * Forcing `Cache-Control: no-cache, must-revalidate, max-age=0`
 * on the entry HTML makes every reload hit the origin (or at
 * minimum validate against the ETag), and `Vary: Cookie` keeps
 * admin and public visitors on separate cache entries — the
 * gallery page POSTs an empty-password admin probe with
 * credentials, and the rendered state diverges by cookie. The
 * hashed bundles are unaffected (this only touches `text/html`
 * responses), so the immutable-cache benefit on the heavy assets
 * is preserved.
 */
function withFreshHtmlHeaders(response) {
  if (!response) return response;
  const contentType = String(response.headers.get('content-type') || '').toLowerCase();
  if (!contentType.includes('text/html')) return response;
  const headers = new Headers(response.headers);
  headers.set('Cache-Control', 'no-cache, must-revalidate, max-age=0');
  const existingVary = headers.get('Vary');
  if (!existingVary) {
    headers.set('Vary', 'Cookie');
  } else if (!/\bcookie\b/i.test(existingVary)) {
    headers.set('Vary', `${existingVary}, Cookie`);
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers
  });
}

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null, { headers: responseCorsHeaders(request) });
    const url = new URL(request.url);

    try {
	      if (request.method === 'GET' && url.pathname === '/') {
	        return withFreshHtmlHeaders(
	          new Response(rootHomepage(), { headers: { 'Content-Type': 'text/html; charset=utf-8' } })
	        );
	      }
	      // /admin and /invcs were duplicate UI surfaces that we retired
	      // in the unified-frame migration. _redirects sends /admin → /db/
	      // and /invcs → /inv/. We intentionally do NOT short-circuit here
	      // so the static _redirects file owns the behaviour.
	      if (request.method === 'GET' && ['/inv', '/inv/', '/invoice', '/invoice/', '/inv/index.html'].includes(url.pathname)) {
        const assetUrl = new URL(request.url);
        assetUrl.pathname = '/inv/';
        return withFreshHtmlHeaders(await env.ASSETS.fetch(new Request(assetUrl.toString(), request)));
      }
      if (request.method === 'GET' && ['/l', '/l/', '/l/index.html'].includes(url.pathname)) {
        const assetUrl = new URL(request.url);
        assetUrl.pathname = '/l/';
        return withFreshHtmlHeaders(await env.ASSETS.fetch(new Request(assetUrl.toString(), request)));
      }
      if (request.method === 'GET' && ['/t', '/t/', '/t/index.html'].includes(url.pathname)) {
        const assetUrl = new URL(request.url);
        assetUrl.pathname = '/t/';
        return withFreshHtmlHeaders(await env.ASSETS.fetch(new Request(assetUrl.toString(), request)));
      }
      if (request.method === 'GET' && ['/db', '/db/', '/db/index.html'].includes(url.pathname)) {
        const assetUrl = new URL(request.url);
        assetUrl.pathname = '/db/';
        return withFreshHtmlHeaders(await env.ASSETS.fetch(new Request(assetUrl.toString(), request)));
      }
      // /g is an internal asset mount for the delivery SPA, not a
      // public landing page. Delivery links have one canonical public
      // entry point: /<short_code>.
      if (request.method === 'GET' && ['/g', '/g/', '/g/index.html'].includes(url.pathname)) {
        return withFreshHtmlHeaders(
          new Response(notFoundPage(url.pathname), { status: 404, headers: { 'Content-Type': 'text/html; charset=utf-8' } })
        );
      }
      if (request.method === 'POST' && url.pathname === '/api/admin-check') return await handleAdminCheck(request, env);
      if (request.method === 'POST' && url.pathname === '/api/invoices-save') return await handleInvoiceSave(request, env);
      if (request.method === 'GET' && url.pathname === '/api/invoices-get') return await handleInvoiceGet(request, env);
      if (request.method === 'GET' && url.pathname === '/api/public-invoice') return await handlePublicInvoiceGet(request, env);
      if (request.method === 'POST' && url.pathname === '/api/invoices-delete') return await handleInvoiceDelete(request, env);
      if (request.method === 'GET' && url.pathname === '/api/packages') return await handlePackagesGet(request, env);
      if (request.method === 'POST' && url.pathname === '/api/packages-save') return await handlePackageSave(request, env);
      if (request.method === 'POST' && url.pathname === '/api/packages-delete') return await handlePackageDelete(request, env);
      if (request.method === 'POST' && url.pathname === '/api/save') return await handleSave(request, env);
      if (request.method === 'GET' && url.pathname === '/api/admin-open-delivery') return await handleAdminOpenDelivery(request, env);
      if (request.method === 'POST' && url.pathname === '/api/unlock') return await handleUnlock(request, env);
      if (request.method === 'GET' && url.pathname === '/api/public-payment-proofs') return await handlePublicPaymentProofsGet(request, env);
      if (request.method === 'GET' && url.pathname === '/api/public-payment-proof-image') return await handlePublicPaymentProofImageGet(request, env);
      if (request.method === 'POST' && url.pathname === '/api/public-payment-proof-delete') return await handlePublicPaymentProofDelete(request, env);
      if (request.method === 'POST' && url.pathname === '/api/payment-proof-submit') return await handlePaymentProofSubmit(request, env);
      if (request.method === 'GET' && url.pathname === '/api/payment-proof-image') return await handlePaymentProofImageGet(request, env);
      if (request.method === 'POST' && url.pathname === '/api/payment-proof-review') return await handlePaymentProofReview(request, env);
      if (request.method === 'POST' && url.pathname === '/api/click') return await handleClick(request, env);
      if (request.method === 'GET' && url.pathname === '/api/open-link') return await handleOpenLink(request, env);
	      if (request.method === 'GET' && url.pathname === '/api/db') return await handleDbSearch(request, env);
	      if (request.method === 'POST' && url.pathname === '/api/clients-save') return await handleClientSave(request, env);
	      if (request.method === 'POST' && url.pathname === '/api/clients-delete') return await handleClientDelete(request, env);
	      if (request.method === 'POST' && url.pathname === '/api/db-password') return await handleDbPasswordChange(request, env);
	      if (request.method === 'POST' && url.pathname === '/api/db-delete') return await handleDbDelete(request, env);
	      if (request.method === 'POST' && url.pathname === '/api/db-clear-logs') return await handleDbClearLogs(request, env);
	      if (request.method === 'POST' && url.pathname === '/api/db-repair-delivery') return await handleDbRepairDelivery(request, env);
	      if (request.method === 'POST' && url.pathname === '/api/db-update-delivery') return await handleDbUpdateDelivery(request, env);

      const shortAliasMatch = url.pathname.match(/^\/([a-z0-9]{7}|[a-z0-9]{12})\/?$/i);
      if (request.method === 'GET' && shortAliasMatch) {
        const limited = enforceRateLimit(request, 'short-alias', { limit: 40, windowMs: 60 * 1000, blockMs: 10 * 60 * 1000 }, false);
        if (limited) return limited;
        const shortCode = cleanShortCode(shortAliasMatch[1]);
        const delivery = shortCode ? await getDeliveryByShortCode(env, shortCode) : null;
        if (delivery) {
          const adminView = await verifyAdminSessionCookie(request, env);
          await insertLog(env, request, delivery.id, adminView ? 'admin_page_view' : 'page_view');
          const assetUrl = new URL(request.url);
          assetUrl.pathname = '/g/';
          return withFreshHtmlHeaders(await env.ASSETS.fetch(new Request(assetUrl.toString(), request)));
        }
        // Unknown short code: serve a real 404 so the address bar
        // keeps the URL the visitor typed (a 302 to "/" hid that)
        // and the browser marks the response as an error. Bots
        // walking the short-code space hit both this 404 and the
        // 40/min rate limit we already consumed above.
        return withFreshHtmlHeaders(
          new Response(notFoundPage(url.pathname), { status: 404, headers: { 'Content-Type': 'text/html; charset=utf-8' } })
        );
      }

      const galleryMatch = url.pathname.match(/^\/g\/([^/]+)\/?$/i);
      if (request.method === 'GET' && galleryMatch) {
        const limited = enforceRateLimit(request, 'gallery-slug', { limit: 60, windowMs: 60 * 1000, blockMs: 10 * 60 * 1000 }, false);
        if (limited) return limited;
        const raw = decodeURIComponent(galleryMatch[1]);
        const shortCode = cleanShortCode(raw);
        const delivery = shortCode
          ? await getDeliveryByShortCode(env, shortCode)
          : await getLatestDeliveryBySlug(env, normalizeGalleryCode(raw) || cleanSlug(raw));
        if (shouldBlockFolderSlug(delivery)) {
          // Keep the existing privacy rule for admin-only folder slugs.
          return withFreshHtmlHeaders(
            new Response(notFoundPage(url.pathname), { status: 404, headers: { 'Content-Type': 'text/html; charset=utf-8' } })
          );
        }
        const canonicalCode = delivery ? explicitShortCode(delivery) : '';
        if (canonicalCode) return Response.redirect(`${url.origin}/${canonicalCode}`, 301);
        return withFreshHtmlHeaders(
          new Response(notFoundPage(url.pathname), { status: 404, headers: { 'Content-Type': 'text/html; charset=utf-8' } })
        );
      }

      const oldDeliveryMatch = url.pathname.match(/^\/l\/([^/]+)\/?$/i);
      if (request.method === 'GET' && oldDeliveryMatch) {
        const raw = decodeURIComponent(oldDeliveryMatch[1]);
        const delivery = await getLatestDeliveryBySlug(env, normalizeGalleryCode(raw) || cleanSlug(raw));
        const canonicalCode = delivery ? explicitShortCode(delivery) : '';
        if (canonicalCode) return Response.redirect(`${url.origin}/${canonicalCode}`, 301);
        return withFreshHtmlHeaders(
          new Response(notFoundPage(url.pathname), { status: 404, headers: { 'Content-Type': 'text/html; charset=utf-8' } })
        );
      }
    } catch (error) {
      if (url.pathname.startsWith('/api/')) {
        // Log full diagnostic detail (status, PostgREST code, message)
        // server-side, but return a short user-facing message so the
        // /db UI never paints a raw Supabase JSON blob across the
        // panel. The client maps this into "Database request failed.
        // Check API configuration."
        if (error?.supabase) {
          console.warn(`[api] ${url.pathname} supabase ${error.status || ''} ${error.code || ''} ${error.message || ''}`);
          return json({ error: 'Database request failed. Check API configuration.', code: error.code || undefined }, 500);
        }
        return json({ error: error.message || 'Server error.' }, 500);
      }
      return new Response(notFoundPage(url.pathname), { status: 500, headers: { 'Content-Type': 'text/html; charset=utf-8' } });
    }

    return await assetOrFallback(request, env);
  }
};

/**
 * Catch-all asset handler with a real 404 for unknown HTML pages.
 *
 * Behaviour:
 *   - Hands every unrouted request to env.ASSETS.fetch(...).
 *   - If the asset exists (any 2xx/3xx, or a 404 from a non-HTML
 *     request like `/missing.png`), pass it through unchanged. We
 *     never want to upgrade an <img> 404 to an HTML page.
 *   - If the asset is missing AND the visitor is asking for a page
 *     (Accept header includes text/html on a GET — true for every
 *     address-bar navigation), rate-limit the IP+scope
 *     'unknown-path', then serve a styled 404 (notFoundPage).
 *     The address bar keeps the URL the visitor typed (a redirect
 *     hid that and made `/in` show the homepage), and the browser
 *     sees a real 404 status.
 *   - Reserved paths (/, /admin, /db, /inv, /l, /g/<slug>, /<short>)
 *     are handled earlier in fetch() and never reach this code, so
 *     a legitimate visit there is never counted against this scope.
 *   - All other 404s (POST/PUT, fetch()/XHR without an explicit
 *     text/html Accept, missing /foo.png, missing /api/whatever)
 *     get the original 404 untouched.
 *
 * Rate limit: 3 attempts per minute, then block the IP for 5 min.
 * Tight on purpose — typing a wrong URL more than three times in a
 * minute is almost always a script walking the URL space looking
 * for short codes. Legitimate visitors rarely fat-finger that fast,
 * and if they do the existing-route limits (40/min on /<short>,
 * 60/min on /g/<slug>) stay generous because reserved paths never
 * spend this scope's budget.
 */
async function assetOrFallback(request, env) {
  const response = await env.ASSETS.fetch(request);
  if (response.status !== 404) return response;
  if (request.method !== 'GET') return response;

  const accept = request.headers.get('accept') || '';
  // Only synthesize an HTML 404 when the visitor is clearly asking
  // for a page. A bare `Accept: */*` or empty (typical of fetch()
  // and XHR without an explicit Accept) keeps the original 404 —
  // turning a missing JSON or image into HTML would be worse.
  if (!accept.includes('text/html')) return response;

  const limited = enforceRateLimit(
    request,
    'unknown-path',
    { limit: 3, windowMs: 60 * 1000, blockMs: 5 * 60 * 1000 },
    false
  );
  if (limited) return limited;

  const url = new URL(request.url);
  return new Response(notFoundPage(url.pathname), {
    status: 404,
    headers: { 'Content-Type': 'text/html; charset=utf-8' }
  });
}
